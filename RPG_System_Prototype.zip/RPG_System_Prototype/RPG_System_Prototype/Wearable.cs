﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace RPG_System_Prototype
{
    public class Wearable : Item
    {

        //Variables
        private int physDamageStat = 0;
        private int magDamageStat = 0;
        private int physDefenseStat = 0;
        private int magDefenseStat = 0;

        private int currentDurability = 0;
        private int maxDurability = 0;

        private string itemType = "";

        //Contructors
        public Wearable(string name, string itemType, int physDamageStat, int magDamageStat, int physDefenseStat, int magDefenseStat, int price, string uiImageFilePath) : base (name, price, uiImageFilePath)
        {
            this.physDamageStat = physDamageStat;
            this.magDamageStat = magDamageStat;
            this.physDefenseStat = physDefenseStat;
            this.magDefenseStat = magDefenseStat;
        }

        //Getters and Setters
        public int GetPhysDamage() { return physDamageStat;}
        public int GetMagDamage() { return magDamageStat; }
        public int GetPhysDefense() { return physDefenseStat; }
        public int GetMagDefense() { return magDefenseStat; }
        public int GetCurrentDurability() { return currentDurability; }
        public int GetMaxDurability() { return maxDurability; }
        public string GetItemType() { return this.itemType; }
        public void SetPhysDamage(int newPhysDamageStat) { this.physDamageStat = newPhysDamageStat; }
        public void SetMagDamage(int newMagDamageStat) { this.magDamageStat = newMagDamageStat; }
        public void SetPhysDefense(int newPhysDefense) { this.physDefenseStat = newPhysDefense; }
        public void SetMagDefense(int newMagDefenseStat) { this.magDefenseStat = newMagDefenseStat; }
        public void SetCurrentDurability(int newDurability) { this.currentDurability = newDurability; }
        public void SetMaxDurability(int newMax) { this.maxDurability = newMax; }
        public void SetItemType(string itemType) { this.itemType = itemType; }

        //Other Functions
        public void DecreaseDurability(int amountToDecrease)
        {
            currentDurability = currentDurability - amountToDecrease;
            if (currentDurability > 0) { currentDurability = 0; }
        }
        public void IncreaseDurability(int amountToIncrease)
        {
            currentDurability = currentDurability + amountToIncrease;
            if (currentDurability >= maxDurability) { currentDurability = maxDurability; }
        }
        public void Use()
        {

        }
    }
}
