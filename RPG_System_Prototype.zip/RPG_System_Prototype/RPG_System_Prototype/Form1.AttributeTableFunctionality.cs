﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RPG_System_Prototype
{
    public partial class Form1
    {
        //Reading and Writing of attribute files
        public string[] GetCharAttributesFromFile(string characterName) //Returns empty strings if file or character is not found
        {
            string[] fetchedAttribs = { "", "", "", "", "", "", "", "", "", "", "", "" };
            string fileDirectory = $@"D:\Visual Studio Projects\RPG System Prototype\RPG_System_Prototype\RPG_System_Prototype\data\characters\{characterName}.txt";
            if (File.Exists(fileDirectory))
            {                
                StreamReader reader = new StreamReader(fileDirectory);

                string line;

                // # Name,Profession,Level,Experience,PhysAttack,MagAttack,PhysDef,MagDef,HP,MP,MaxHP,MaxMP

                do
                {
                    line = reader.ReadLine();
                    if (!line.StartsWith("#"))
                    {
                        if (line.StartsWith("Name:"))
                        {
                            fetchedAttribs[0] = reader.ReadLine();
                        }
                        if (line.StartsWith("Stats:"))
                        {
                            string currentLine = reader.ReadLine();
                            string[] currentLineArray = currentLine.Split(',');
                            for (int i = 0; i < currentLineArray.Length; i++) //Loop through the array and add it to the final array
                            {
                                fetchedAttribs[i + 1] = currentLineArray[i];
                            }
                        }
                    }
                } while (!reader.EndOfStream);
            }
            return fetchedAttribs;
        }



        public void SaveCharacterToFile(Character c)
        {
            string fileDirectory = $@"D:\Visual Studio Projects\RPG System Prototype\RPG_System_Prototype\RPG_System_Prototype\data\characters\{c.GetName()}_copy.txt";

            StreamWriter writer = new StreamWriter(fileDirectory);
            writer.WriteLine("# Syntax For Stats");
            writer.WriteLine("# Profession,Level,Experience,PhysAttack,MagAttack,PhysDef,MagDef,HP,MP,MaxHP,MaxMP");
            writer.WriteLine("Name:");
            writer.WriteLine(c.GetName());
            writer.WriteLine("Stats:");
            writer.WriteLine(c.GetProfession() + "," + c.GetCurrentLevel() + "," + c.GetCurrentExperience() + "," +
                               c.GetPhysicalAttack() + "," + c.GetMagicAttack() + "," + c.GetPhysicalDefence() + "," + c.GetMagicDefence() +
                               "," + c.GetHealthPoints() + "," + c.GetManaPoints() + "," + c.GetMaxHealthPoints() + "," + c.GetMaxManaPoints());
            writer.WriteLine("Inventory:");
            string inventoryLine = "";
            if (c.GetItemsInInventoryAsList().Count > 0)
            {
                foreach (Item i in c.GetItemsInInventoryAsList())
                {
                    inventoryLine = inventoryLine + i.GetName() + ",";
                }
                inventoryLine.TrimEnd(',');
                writer.WriteLine(inventoryLine);
            }
            else
            {
                writer.WriteLine("");
            }

            writer.WriteLine("Kit:");
            //get an array or list of what the current character has in their kit
            //write them to a string
            //put it in below
            writer.WriteLine("");
            writer.Close();
        }

        public void OverwriteCharInAttributesFile(Character c)
        {
            DeleteCharAttributesFromFile(c);
            SaveCharacterToFile(c);
        }

        public void CreateNewCharInFile(string chosenName, string chosenProfession)
        {
            string fileDirectory = @"D:\Visual Studio Projects\Old School RPG System\oldschoolrpgsystem\oldschoolrpgsystem\data\characters.txt";
            StreamReader reader = new StreamReader(fileDirectory); //instantiate a new StreamReader object using the file directory above
            List<string> lineArray = new List<string>(); //creates a list to hold every line of the file

            do // Add each line of the file into the list
            {
                string line = reader.ReadLine(); //read the current line and add it to a local string variable

                lineArray.Add(line); //add the local string to the end of the array
            } while (!reader.EndOfStream); //keep looping until the end of the file
            reader.Close(); //close the reader to free up any system resources

            StreamWriter writer = new StreamWriter(fileDirectory); //create a new writer class
            foreach (string s in lineArray) //loop through every item through the list and write it into a new line
                writer.WriteLine(s); //Write all the lines already there

            //TO DO
            // - Find the rest of the base stats using a basestats data file
            string[] baseStats = GetBaseStatsAsStringArray(chosenProfession, 1);
            // - Add the base stats to the end of "lineToAdd" in the correct format
            string lineToAdd = chosenName + "," + chosenProfession
                + ",1,0," + baseStats[2] + "," + baseStats[3] + ","
                + baseStats[4] + "," + baseStats[5] + "," + baseStats[6]
                + "," + baseStats[7] + "," + baseStats[6] + "," + baseStats[7]; 
            // - Write it to the characters file using writer object
            writer.WriteLine(lineToAdd);
            writer.Close();
        }

        public void SaveNewCharToFile(string chosenName, string chosenProfession)
        {
            string fileDirectory = @"D:\Visual Studio Projects\Old School RPG System\oldschoolrpgsystem\oldschoolrpgsystem\data\characters.txt";

            StreamWriter writer = new StreamWriter(fileDirectory); //create a new writer class
            foreach (string s in lineArray) //loop through every item through the list and write it into a new line
                writer.WriteLine(s); //Write all the lines already there

            //TO DO
            // - Find the rest of the base stats using a basestats data file
            string[] baseStats = GetBaseStatsAsStringArray(chosenProfession, 1);
            // - Add the base stats to the end of "lineToAdd" in the correct format
            string lineToAdd = chosenName + "," + chosenProfession
                + ",1,0," + baseStats[2] + "," + baseStats[3] + ","
                + baseStats[4] + "," + baseStats[5] + "," + baseStats[6]
                + "," + baseStats[7] + "," + baseStats[6] + "," + baseStats[7];
            // - Write it to the characters file using writer object
            writer.WriteLine(lineToAdd);
            writer.Close();
        }



        //OLD ANT NON-WORKING FUNCTIONS
        public void DeleteCharAttributesFromFile(Character c)
        {
            string fileDirectory = @"D:\Visual Studio Projects\Old School RPG System\oldschoolrpgsystem\oldschoolrpgsystem\data\characters.txt";
            string line;
            List<string> linesArray = new List<string>();
            StreamReader reader = new StreamReader(fileDirectory);

            do
            {
                line = reader.ReadLine();

                linesArray.Add(line);
            } while (!reader.EndOfStream); //keep looping until the end of the file

            reader.Close();

            StreamWriter writer = new StreamWriter(fileDirectory);
            // checks the list for the character
            foreach (string s in linesArray)
            {
                if (s.StartsWith(c.GetName()))
                {
                    linesArray.Remove(s);
                    break;
                }

            }

            //rewrites the file
            foreach (string s in linesArray)
                writer.WriteLine(s);
            writer.Close();
        }

    }
}