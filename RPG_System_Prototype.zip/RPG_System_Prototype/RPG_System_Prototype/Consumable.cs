﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace RPG_System_Prototype
{
    public class Consumable : Item
    {
        private int maxHealthToRestore;
        private int maxManaToRestore;
        private int restorationIncrement;

        public Consumable(string name, int price, int healthVal, int manaVal, int restoreInc, string uiImageFilePath) : base(name, price, uiImageFilePath)
        {
            maxHealthToRestore = healthVal;
            maxManaToRestore = manaVal;
            restorationIncrement = restoreInc;
        }

        //Getters and Setters
        public int GetHealthAmount() { return maxHealthToRestore; }
        public int GetManaAmount() { return maxManaToRestore; }
        public int GetRestoreIncrement() { return restorationIncrement; }
        public void SetHealthAmount(int newHealthAmount) { maxHealthToRestore = newHealthAmount; }
        public void SetManaAmount(int newManaAmount) { maxManaToRestore = newManaAmount; }
        public void SetRestorationIncrement(int newAmount) { restorationIncrement = newAmount; }
    }
}
