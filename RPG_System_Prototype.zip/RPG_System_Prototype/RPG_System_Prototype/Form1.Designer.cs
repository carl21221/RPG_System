﻿namespace RPG_System_Prototype
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.grpbox_LogIn = new System.Windows.Forms.GroupBox();
            this.btn_LogIn_CreateNew = new System.Windows.Forms.Button();
            this.lbl_LogIn_Name = new System.Windows.Forms.Label();
            this.btn_LogIn = new System.Windows.Forms.Button();
            this.txtbox_LogIn_Name = new System.Windows.Forms.TextBox();
            this.lbl_Character_Name = new System.Windows.Forms.Label();
            this.lbl_Character_ExpProgress = new System.Windows.Forms.Label();
            this.lbl_Character_PhysAttack = new System.Windows.Forms.Label();
            this.lbl_Character_PhysDefence = new System.Windows.Forms.Label();
            this.lbl_Character_MagicAttack = new System.Windows.Forms.Label();
            this.lbl_Character_MagicDefence = new System.Windows.Forms.Label();
            this.lbl_Character_HealthPoints = new System.Windows.Forms.Label();
            this.lbl_Character_ManaPoints = new System.Windows.Forms.Label();
            this.lstbox_Character_Kit = new System.Windows.Forms.ListBox();
            this.lstbox_Character_Inventory = new System.Windows.Forms.ListBox();
            this.gropbox_Character_Info = new System.Windows.Forms.GroupBox();
            this.gropbox_New_Character = new System.Windows.Forms.GroupBox();
            this.btn_NewCharacter_Cancel = new System.Windows.Forms.Button();
            this.btn_NewCharacter_Create = new System.Windows.Forms.Button();
            this.lbl_NewCharacter_Profession = new System.Windows.Forms.Label();
            this.lbl_NewCharacter_Name = new System.Windows.Forms.Label();
            this.lstbox_NewCharacter_Profession = new System.Windows.Forms.ListBox();
            this.txtbox_NewCharacter_Name = new System.Windows.Forms.TextBox();
            this.grpbox_MonsterInfo = new System.Windows.Forms.GroupBox();
            this.lbl_Monster_MagicDefence = new System.Windows.Forms.Label();
            this.lbl_Monster_MagicAttack = new System.Windows.Forms.Label();
            this.lbl_Monster_PhysDefence = new System.Windows.Forms.Label();
            this.lbl_Monster_PhysAttack = new System.Windows.Forms.Label();
            this.lbl_Monster_HealthPoints = new System.Windows.Forms.Label();
            this.lbl_Monster_Name = new System.Windows.Forms.Label();
            this.grpbox_FloorItems = new System.Windows.Forms.GroupBox();
            this.lstbox_FloorItems = new System.Windows.Forms.ListBox();
            this.grpbox_Character_Actions = new System.Windows.Forms.GroupBox();
            this.btn_Character_DropItem = new System.Windows.Forms.Button();
            this.btn_Character_PickUpItem = new System.Windows.Forms.Button();
            this.btn_Character_RemoveItem = new System.Windows.Forms.Button();
            this.btn_Character_EquipItem = new System.Windows.Forms.Button();
            this.btn_Character_UseConsumable = new System.Windows.Forms.Button();
            this.btn_Character_Attack = new System.Windows.Forms.Button();
            this.FrameTime = new System.Windows.Forms.Timer(this.components);
            this.btn_Character_Save = new System.Windows.Forms.Button();
            this.grpbox_LogIn.SuspendLayout();
            this.gropbox_Character_Info.SuspendLayout();
            this.gropbox_New_Character.SuspendLayout();
            this.grpbox_MonsterInfo.SuspendLayout();
            this.grpbox_FloorItems.SuspendLayout();
            this.grpbox_Character_Actions.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpbox_LogIn
            // 
            this.grpbox_LogIn.BackColor = System.Drawing.Color.Transparent;
            this.grpbox_LogIn.Controls.Add(this.btn_LogIn_CreateNew);
            this.grpbox_LogIn.Controls.Add(this.lbl_LogIn_Name);
            this.grpbox_LogIn.Controls.Add(this.btn_LogIn);
            this.grpbox_LogIn.Controls.Add(this.txtbox_LogIn_Name);
            this.grpbox_LogIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.grpbox_LogIn.ForeColor = System.Drawing.Color.White;
            this.grpbox_LogIn.Location = new System.Drawing.Point(735, 17);
            this.grpbox_LogIn.Name = "grpbox_LogIn";
            this.grpbox_LogIn.Size = new System.Drawing.Size(349, 106);
            this.grpbox_LogIn.TabIndex = 0;
            this.grpbox_LogIn.TabStop = false;
            this.grpbox_LogIn.Text = "Log In To Character";
            // 
            // btn_LogIn_CreateNew
            // 
            this.btn_LogIn_CreateNew.BackColor = System.Drawing.Color.White;
            this.btn_LogIn_CreateNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LogIn_CreateNew.ForeColor = System.Drawing.Color.Black;
            this.btn_LogIn_CreateNew.Location = new System.Drawing.Point(180, 65);
            this.btn_LogIn_CreateNew.Name = "btn_LogIn_CreateNew";
            this.btn_LogIn_CreateNew.Size = new System.Drawing.Size(150, 30);
            this.btn_LogIn_CreateNew.TabIndex = 3;
            this.btn_LogIn_CreateNew.Text = "Create New";
            this.btn_LogIn_CreateNew.UseVisualStyleBackColor = false;
            this.btn_LogIn_CreateNew.Click += new System.EventHandler(this.btn_LogIn_CreateNew_Click);
            // 
            // lbl_LogIn_Name
            // 
            this.lbl_LogIn_Name.AutoSize = true;
            this.lbl_LogIn_Name.Location = new System.Drawing.Point(8, 30);
            this.lbl_LogIn_Name.Name = "lbl_LogIn_Name";
            this.lbl_LogIn_Name.Size = new System.Drawing.Size(58, 20);
            this.lbl_LogIn_Name.TabIndex = 2;
            this.lbl_LogIn_Name.Text = "Name:";
            // 
            // btn_LogIn
            // 
            this.btn_LogIn.BackColor = System.Drawing.Color.White;
            this.btn_LogIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LogIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_LogIn.ForeColor = System.Drawing.Color.Black;
            this.btn_LogIn.Location = new System.Drawing.Point(17, 65);
            this.btn_LogIn.Name = "btn_LogIn";
            this.btn_LogIn.Size = new System.Drawing.Size(150, 30);
            this.btn_LogIn.TabIndex = 1;
            this.btn_LogIn.Text = "Log In";
            this.btn_LogIn.UseVisualStyleBackColor = false;
            this.btn_LogIn.Click += new System.EventHandler(this.btn_LogIn_Click);
            // 
            // txtbox_LogIn_Name
            // 
            this.txtbox_LogIn_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtbox_LogIn_Name.Location = new System.Drawing.Point(67, 28);
            this.txtbox_LogIn_Name.Name = "txtbox_LogIn_Name";
            this.txtbox_LogIn_Name.Size = new System.Drawing.Size(263, 26);
            this.txtbox_LogIn_Name.TabIndex = 0;
            // 
            // lbl_Character_Name
            // 
            this.lbl_Character_Name.AutoSize = true;
            this.lbl_Character_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Character_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Character_Name.ForeColor = System.Drawing.Color.White;
            this.lbl_Character_Name.Location = new System.Drawing.Point(15, 22);
            this.lbl_Character_Name.Name = "lbl_Character_Name";
            this.lbl_Character_Name.Size = new System.Drawing.Size(172, 26);
            this.lbl_Character_Name.TabIndex = 1;
            this.lbl_Character_Name.Text = "Character Name";
            // 
            // lbl_Character_ExpProgress
            // 
            this.lbl_Character_ExpProgress.AutoSize = true;
            this.lbl_Character_ExpProgress.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Character_ExpProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Character_ExpProgress.ForeColor = System.Drawing.Color.White;
            this.lbl_Character_ExpProgress.Location = new System.Drawing.Point(15, 48);
            this.lbl_Character_ExpProgress.Name = "lbl_Character_ExpProgress";
            this.lbl_Character_ExpProgress.Size = new System.Drawing.Size(121, 26);
            this.lbl_Character_ExpProgress.TabIndex = 2;
            this.lbl_Character_ExpProgress.Text = "Experience";
            // 
            // lbl_Character_PhysAttack
            // 
            this.lbl_Character_PhysAttack.AutoSize = true;
            this.lbl_Character_PhysAttack.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Character_PhysAttack.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Character_PhysAttack.ForeColor = System.Drawing.Color.White;
            this.lbl_Character_PhysAttack.Location = new System.Drawing.Point(15, 126);
            this.lbl_Character_PhysAttack.Name = "lbl_Character_PhysAttack";
            this.lbl_Character_PhysAttack.Size = new System.Drawing.Size(161, 26);
            this.lbl_Character_PhysAttack.TabIndex = 3;
            this.lbl_Character_PhysAttack.Text = "Physical Attack";
            // 
            // lbl_Character_PhysDefence
            // 
            this.lbl_Character_PhysDefence.AutoSize = true;
            this.lbl_Character_PhysDefence.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Character_PhysDefence.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Character_PhysDefence.ForeColor = System.Drawing.Color.White;
            this.lbl_Character_PhysDefence.Location = new System.Drawing.Point(15, 153);
            this.lbl_Character_PhysDefence.Name = "lbl_Character_PhysDefence";
            this.lbl_Character_PhysDefence.Size = new System.Drawing.Size(181, 26);
            this.lbl_Character_PhysDefence.TabIndex = 4;
            this.lbl_Character_PhysDefence.Text = "Physical Defence";
            // 
            // lbl_Character_MagicAttack
            // 
            this.lbl_Character_MagicAttack.AutoSize = true;
            this.lbl_Character_MagicAttack.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Character_MagicAttack.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Character_MagicAttack.ForeColor = System.Drawing.Color.White;
            this.lbl_Character_MagicAttack.Location = new System.Drawing.Point(15, 180);
            this.lbl_Character_MagicAttack.Name = "lbl_Character_MagicAttack";
            this.lbl_Character_MagicAttack.Size = new System.Drawing.Size(137, 26);
            this.lbl_Character_MagicAttack.TabIndex = 5;
            this.lbl_Character_MagicAttack.Text = "Magic Attack";
            // 
            // lbl_Character_MagicDefence
            // 
            this.lbl_Character_MagicDefence.AutoSize = true;
            this.lbl_Character_MagicDefence.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Character_MagicDefence.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Character_MagicDefence.ForeColor = System.Drawing.Color.White;
            this.lbl_Character_MagicDefence.Location = new System.Drawing.Point(15, 207);
            this.lbl_Character_MagicDefence.Name = "lbl_Character_MagicDefence";
            this.lbl_Character_MagicDefence.Size = new System.Drawing.Size(157, 26);
            this.lbl_Character_MagicDefence.TabIndex = 6;
            this.lbl_Character_MagicDefence.Text = "Magic Defence";
            // 
            // lbl_Character_HealthPoints
            // 
            this.lbl_Character_HealthPoints.AutoSize = true;
            this.lbl_Character_HealthPoints.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Character_HealthPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Character_HealthPoints.ForeColor = System.Drawing.Color.White;
            this.lbl_Character_HealthPoints.Location = new System.Drawing.Point(15, 74);
            this.lbl_Character_HealthPoints.Name = "lbl_Character_HealthPoints";
            this.lbl_Character_HealthPoints.Size = new System.Drawing.Size(49, 26);
            this.lbl_Character_HealthPoints.TabIndex = 7;
            this.lbl_Character_HealthPoints.Text = "HP:";
            // 
            // lbl_Character_ManaPoints
            // 
            this.lbl_Character_ManaPoints.AutoSize = true;
            this.lbl_Character_ManaPoints.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Character_ManaPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Character_ManaPoints.ForeColor = System.Drawing.Color.White;
            this.lbl_Character_ManaPoints.Location = new System.Drawing.Point(15, 99);
            this.lbl_Character_ManaPoints.Name = "lbl_Character_ManaPoints";
            this.lbl_Character_ManaPoints.Size = new System.Drawing.Size(51, 26);
            this.lbl_Character_ManaPoints.TabIndex = 8;
            this.lbl_Character_ManaPoints.Text = "MP:";
            // 
            // lstbox_Character_Kit
            // 
            this.lstbox_Character_Kit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lstbox_Character_Kit.FormattingEnabled = true;
            this.lstbox_Character_Kit.ItemHeight = 20;
            this.lstbox_Character_Kit.Location = new System.Drawing.Point(231, 54);
            this.lstbox_Character_Kit.Name = "lstbox_Character_Kit";
            this.lstbox_Character_Kit.Size = new System.Drawing.Size(195, 184);
            this.lstbox_Character_Kit.TabIndex = 9;
            // 
            // lstbox_Character_Inventory
            // 
            this.lstbox_Character_Inventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lstbox_Character_Inventory.FormattingEnabled = true;
            this.lstbox_Character_Inventory.ItemHeight = 20;
            this.lstbox_Character_Inventory.Location = new System.Drawing.Point(458, 53);
            this.lstbox_Character_Inventory.Name = "lstbox_Character_Inventory";
            this.lstbox_Character_Inventory.Size = new System.Drawing.Size(195, 184);
            this.lstbox_Character_Inventory.TabIndex = 10;
            // 
            // gropbox_Character_Info
            // 
            this.gropbox_Character_Info.BackColor = System.Drawing.Color.Transparent;
            this.gropbox_Character_Info.Controls.Add(this.lbl_Character_Name);
            this.gropbox_Character_Info.Controls.Add(this.lbl_Character_ExpProgress);
            this.gropbox_Character_Info.Controls.Add(this.lbl_Character_PhysAttack);
            this.gropbox_Character_Info.Controls.Add(this.lstbox_Character_Inventory);
            this.gropbox_Character_Info.Controls.Add(this.lbl_Character_PhysDefence);
            this.gropbox_Character_Info.Controls.Add(this.lstbox_Character_Kit);
            this.gropbox_Character_Info.Controls.Add(this.lbl_Character_MagicAttack);
            this.gropbox_Character_Info.Controls.Add(this.lbl_Character_ManaPoints);
            this.gropbox_Character_Info.Controls.Add(this.lbl_Character_MagicDefence);
            this.gropbox_Character_Info.Controls.Add(this.lbl_Character_HealthPoints);
            this.gropbox_Character_Info.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.gropbox_Character_Info.ForeColor = System.Drawing.Color.White;
            this.gropbox_Character_Info.Location = new System.Drawing.Point(12, 12);
            this.gropbox_Character_Info.Name = "gropbox_Character_Info";
            this.gropbox_Character_Info.Size = new System.Drawing.Size(684, 265);
            this.gropbox_Character_Info.TabIndex = 13;
            this.gropbox_Character_Info.TabStop = false;
            this.gropbox_Character_Info.Text = "Character Info";
            this.gropbox_Character_Info.Visible = false;
            // 
            // gropbox_New_Character
            // 
            this.gropbox_New_Character.BackColor = System.Drawing.Color.Transparent;
            this.gropbox_New_Character.Controls.Add(this.btn_NewCharacter_Cancel);
            this.gropbox_New_Character.Controls.Add(this.btn_NewCharacter_Create);
            this.gropbox_New_Character.Controls.Add(this.lbl_NewCharacter_Profession);
            this.gropbox_New_Character.Controls.Add(this.lbl_NewCharacter_Name);
            this.gropbox_New_Character.Controls.Add(this.lstbox_NewCharacter_Profession);
            this.gropbox_New_Character.Controls.Add(this.txtbox_NewCharacter_Name);
            this.gropbox_New_Character.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.gropbox_New_Character.ForeColor = System.Drawing.Color.White;
            this.gropbox_New_Character.Location = new System.Drawing.Point(735, 130);
            this.gropbox_New_Character.Name = "gropbox_New_Character";
            this.gropbox_New_Character.Size = new System.Drawing.Size(349, 168);
            this.gropbox_New_Character.TabIndex = 14;
            this.gropbox_New_Character.TabStop = false;
            this.gropbox_New_Character.Text = "Create New Character";
            this.gropbox_New_Character.Visible = false;
            // 
            // btn_NewCharacter_Cancel
            // 
            this.btn_NewCharacter_Cancel.BackColor = System.Drawing.Color.White;
            this.btn_NewCharacter_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_NewCharacter_Cancel.ForeColor = System.Drawing.Color.Black;
            this.btn_NewCharacter_Cancel.Location = new System.Drawing.Point(177, 129);
            this.btn_NewCharacter_Cancel.Name = "btn_NewCharacter_Cancel";
            this.btn_NewCharacter_Cancel.Size = new System.Drawing.Size(75, 29);
            this.btn_NewCharacter_Cancel.TabIndex = 17;
            this.btn_NewCharacter_Cancel.Text = "Cancel";
            this.btn_NewCharacter_Cancel.UseVisualStyleBackColor = false;
            this.btn_NewCharacter_Cancel.Click += new System.EventHandler(this.btn_NewCharacter_Cancel_Click);
            // 
            // btn_NewCharacter_Create
            // 
            this.btn_NewCharacter_Create.BackColor = System.Drawing.Color.White;
            this.btn_NewCharacter_Create.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_NewCharacter_Create.ForeColor = System.Drawing.Color.Black;
            this.btn_NewCharacter_Create.Location = new System.Drawing.Point(96, 129);
            this.btn_NewCharacter_Create.Name = "btn_NewCharacter_Create";
            this.btn_NewCharacter_Create.Size = new System.Drawing.Size(75, 29);
            this.btn_NewCharacter_Create.TabIndex = 16;
            this.btn_NewCharacter_Create.Text = "Create";
            this.btn_NewCharacter_Create.UseVisualStyleBackColor = false;
            this.btn_NewCharacter_Create.Click += new System.EventHandler(this.btn_NewCharacter_Create_Click);
            // 
            // lbl_NewCharacter_Profession
            // 
            this.lbl_NewCharacter_Profession.AutoSize = true;
            this.lbl_NewCharacter_Profession.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_NewCharacter_Profession.Location = new System.Drawing.Point(6, 60);
            this.lbl_NewCharacter_Profession.Name = "lbl_NewCharacter_Profession";
            this.lbl_NewCharacter_Profession.Size = new System.Drawing.Size(94, 20);
            this.lbl_NewCharacter_Profession.TabIndex = 15;
            this.lbl_NewCharacter_Profession.Text = "Profession:";
            // 
            // lbl_NewCharacter_Name
            // 
            this.lbl_NewCharacter_Name.AutoSize = true;
            this.lbl_NewCharacter_Name.Location = new System.Drawing.Point(6, 28);
            this.lbl_NewCharacter_Name.Name = "lbl_NewCharacter_Name";
            this.lbl_NewCharacter_Name.Size = new System.Drawing.Size(58, 20);
            this.lbl_NewCharacter_Name.TabIndex = 2;
            this.lbl_NewCharacter_Name.Text = "Name:";
            // 
            // lstbox_NewCharacter_Profession
            // 
            this.lstbox_NewCharacter_Profession.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstbox_NewCharacter_Profession.FormattingEnabled = true;
            this.lstbox_NewCharacter_Profession.ItemHeight = 20;
            this.lstbox_NewCharacter_Profession.Items.AddRange(new object[] {
            "Warrior",
            "Mage",
            "Spiritualist"});
            this.lstbox_NewCharacter_Profession.Location = new System.Drawing.Point(106, 60);
            this.lstbox_NewCharacter_Profession.Name = "lstbox_NewCharacter_Profession";
            this.lstbox_NewCharacter_Profession.Size = new System.Drawing.Size(224, 60);
            this.lstbox_NewCharacter_Profession.TabIndex = 1;
            // 
            // txtbox_NewCharacter_Name
            // 
            this.txtbox_NewCharacter_Name.Location = new System.Drawing.Point(106, 25);
            this.txtbox_NewCharacter_Name.Name = "txtbox_NewCharacter_Name";
            this.txtbox_NewCharacter_Name.Size = new System.Drawing.Size(224, 26);
            this.txtbox_NewCharacter_Name.TabIndex = 0;
            // 
            // grpbox_MonsterInfo
            // 
            this.grpbox_MonsterInfo.BackColor = System.Drawing.Color.Transparent;
            this.grpbox_MonsterInfo.Controls.Add(this.lbl_Monster_MagicDefence);
            this.grpbox_MonsterInfo.Controls.Add(this.lbl_Monster_MagicAttack);
            this.grpbox_MonsterInfo.Controls.Add(this.lbl_Monster_PhysDefence);
            this.grpbox_MonsterInfo.Controls.Add(this.lbl_Monster_PhysAttack);
            this.grpbox_MonsterInfo.Controls.Add(this.lbl_Monster_HealthPoints);
            this.grpbox_MonsterInfo.Controls.Add(this.lbl_Monster_Name);
            this.grpbox_MonsterInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.grpbox_MonsterInfo.ForeColor = System.Drawing.Color.White;
            this.grpbox_MonsterInfo.Location = new System.Drawing.Point(12, 408);
            this.grpbox_MonsterInfo.Name = "grpbox_MonsterInfo";
            this.grpbox_MonsterInfo.Size = new System.Drawing.Size(684, 205);
            this.grpbox_MonsterInfo.TabIndex = 15;
            this.grpbox_MonsterInfo.TabStop = false;
            this.grpbox_MonsterInfo.Text = "Monster Info";
            this.grpbox_MonsterInfo.Visible = false;
            this.grpbox_MonsterInfo.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lbl_Monster_MagicDefence
            // 
            this.lbl_Monster_MagicDefence.AutoSize = true;
            this.lbl_Monster_MagicDefence.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Monster_MagicDefence.Location = new System.Drawing.Point(15, 156);
            this.lbl_Monster_MagicDefence.Name = "lbl_Monster_MagicDefence";
            this.lbl_Monster_MagicDefence.Size = new System.Drawing.Size(157, 26);
            this.lbl_Monster_MagicDefence.TabIndex = 5;
            this.lbl_Monster_MagicDefence.Text = "Magic Defence";
            // 
            // lbl_Monster_MagicAttack
            // 
            this.lbl_Monster_MagicAttack.AutoSize = true;
            this.lbl_Monster_MagicAttack.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Monster_MagicAttack.Location = new System.Drawing.Point(15, 130);
            this.lbl_Monster_MagicAttack.Name = "lbl_Monster_MagicAttack";
            this.lbl_Monster_MagicAttack.Size = new System.Drawing.Size(137, 26);
            this.lbl_Monster_MagicAttack.TabIndex = 4;
            this.lbl_Monster_MagicAttack.Text = "Magic Attack";
            // 
            // lbl_Monster_PhysDefence
            // 
            this.lbl_Monster_PhysDefence.AutoSize = true;
            this.lbl_Monster_PhysDefence.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Monster_PhysDefence.Location = new System.Drawing.Point(15, 104);
            this.lbl_Monster_PhysDefence.Name = "lbl_Monster_PhysDefence";
            this.lbl_Monster_PhysDefence.Size = new System.Drawing.Size(181, 26);
            this.lbl_Monster_PhysDefence.TabIndex = 3;
            this.lbl_Monster_PhysDefence.Text = "Physical Defence";
            // 
            // lbl_Monster_PhysAttack
            // 
            this.lbl_Monster_PhysAttack.AutoSize = true;
            this.lbl_Monster_PhysAttack.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Monster_PhysAttack.Location = new System.Drawing.Point(15, 78);
            this.lbl_Monster_PhysAttack.Name = "lbl_Monster_PhysAttack";
            this.lbl_Monster_PhysAttack.Size = new System.Drawing.Size(161, 26);
            this.lbl_Monster_PhysAttack.TabIndex = 2;
            this.lbl_Monster_PhysAttack.Text = "Physical Attack";
            // 
            // lbl_Monster_HealthPoints
            // 
            this.lbl_Monster_HealthPoints.AutoSize = true;
            this.lbl_Monster_HealthPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Monster_HealthPoints.Location = new System.Drawing.Point(15, 52);
            this.lbl_Monster_HealthPoints.Name = "lbl_Monster_HealthPoints";
            this.lbl_Monster_HealthPoints.Size = new System.Drawing.Size(49, 26);
            this.lbl_Monster_HealthPoints.TabIndex = 1;
            this.lbl_Monster_HealthPoints.Text = "HP:";
            // 
            // lbl_Monster_Name
            // 
            this.lbl_Monster_Name.AutoSize = true;
            this.lbl_Monster_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lbl_Monster_Name.Location = new System.Drawing.Point(15, 26);
            this.lbl_Monster_Name.Name = "lbl_Monster_Name";
            this.lbl_Monster_Name.Size = new System.Drawing.Size(155, 26);
            this.lbl_Monster_Name.TabIndex = 0;
            this.lbl_Monster_Name.Text = "Monster Name";
            // 
            // grpbox_FloorItems
            // 
            this.grpbox_FloorItems.BackColor = System.Drawing.Color.Transparent;
            this.grpbox_FloorItems.Controls.Add(this.lstbox_FloorItems);
            this.grpbox_FloorItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.grpbox_FloorItems.ForeColor = System.Drawing.Color.White;
            this.grpbox_FloorItems.Location = new System.Drawing.Point(735, 305);
            this.grpbox_FloorItems.Name = "grpbox_FloorItems";
            this.grpbox_FloorItems.Size = new System.Drawing.Size(349, 308);
            this.grpbox_FloorItems.TabIndex = 16;
            this.grpbox_FloorItems.TabStop = false;
            this.grpbox_FloorItems.Text = "Floor Items";
            this.grpbox_FloorItems.Visible = false;
            // 
            // lstbox_FloorItems
            // 
            this.lstbox_FloorItems.FormattingEnabled = true;
            this.lstbox_FloorItems.ItemHeight = 20;
            this.lstbox_FloorItems.Location = new System.Drawing.Point(13, 25);
            this.lstbox_FloorItems.Name = "lstbox_FloorItems";
            this.lstbox_FloorItems.Size = new System.Drawing.Size(320, 264);
            this.lstbox_FloorItems.TabIndex = 0;
            // 
            // grpbox_Character_Actions
            // 
            this.grpbox_Character_Actions.BackColor = System.Drawing.Color.Transparent;
            this.grpbox_Character_Actions.Controls.Add(this.btn_Character_Save);
            this.grpbox_Character_Actions.Controls.Add(this.btn_Character_DropItem);
            this.grpbox_Character_Actions.Controls.Add(this.btn_Character_PickUpItem);
            this.grpbox_Character_Actions.Controls.Add(this.btn_Character_RemoveItem);
            this.grpbox_Character_Actions.Controls.Add(this.btn_Character_EquipItem);
            this.grpbox_Character_Actions.Controls.Add(this.btn_Character_UseConsumable);
            this.grpbox_Character_Actions.Controls.Add(this.btn_Character_Attack);
            this.grpbox_Character_Actions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.grpbox_Character_Actions.ForeColor = System.Drawing.Color.White;
            this.grpbox_Character_Actions.Location = new System.Drawing.Point(12, 283);
            this.grpbox_Character_Actions.Name = "grpbox_Character_Actions";
            this.grpbox_Character_Actions.Size = new System.Drawing.Size(684, 100);
            this.grpbox_Character_Actions.TabIndex = 17;
            this.grpbox_Character_Actions.TabStop = false;
            this.grpbox_Character_Actions.Text = "Actions";
            this.grpbox_Character_Actions.Visible = false;
            // 
            // btn_Character_DropItem
            // 
            this.btn_Character_DropItem.BackColor = System.Drawing.Color.White;
            this.btn_Character_DropItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Character_DropItem.ForeColor = System.Drawing.Color.Black;
            this.btn_Character_DropItem.Location = new System.Drawing.Point(183, 60);
            this.btn_Character_DropItem.Name = "btn_Character_DropItem";
            this.btn_Character_DropItem.Size = new System.Drawing.Size(150, 30);
            this.btn_Character_DropItem.TabIndex = 6;
            this.btn_Character_DropItem.Text = "Drop Item";
            this.btn_Character_DropItem.UseVisualStyleBackColor = false;
            // 
            // btn_Character_PickUpItem
            // 
            this.btn_Character_PickUpItem.BackColor = System.Drawing.Color.White;
            this.btn_Character_PickUpItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Character_PickUpItem.ForeColor = System.Drawing.Color.Black;
            this.btn_Character_PickUpItem.Location = new System.Drawing.Point(14, 60);
            this.btn_Character_PickUpItem.Name = "btn_Character_PickUpItem";
            this.btn_Character_PickUpItem.Size = new System.Drawing.Size(150, 30);
            this.btn_Character_PickUpItem.TabIndex = 5;
            this.btn_Character_PickUpItem.Text = "Pick Up Item";
            this.btn_Character_PickUpItem.UseVisualStyleBackColor = false;
            // 
            // btn_Character_RemoveItem
            // 
            this.btn_Character_RemoveItem.BackColor = System.Drawing.Color.White;
            this.btn_Character_RemoveItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Character_RemoveItem.ForeColor = System.Drawing.Color.Black;
            this.btn_Character_RemoveItem.Location = new System.Drawing.Point(520, 22);
            this.btn_Character_RemoveItem.Name = "btn_Character_RemoveItem";
            this.btn_Character_RemoveItem.Size = new System.Drawing.Size(150, 30);
            this.btn_Character_RemoveItem.TabIndex = 4;
            this.btn_Character_RemoveItem.Text = "Remove Item";
            this.btn_Character_RemoveItem.UseVisualStyleBackColor = false;
            // 
            // btn_Character_EquipItem
            // 
            this.btn_Character_EquipItem.BackColor = System.Drawing.Color.White;
            this.btn_Character_EquipItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Character_EquipItem.ForeColor = System.Drawing.Color.Black;
            this.btn_Character_EquipItem.Location = new System.Drawing.Point(350, 22);
            this.btn_Character_EquipItem.Name = "btn_Character_EquipItem";
            this.btn_Character_EquipItem.Size = new System.Drawing.Size(150, 30);
            this.btn_Character_EquipItem.TabIndex = 3;
            this.btn_Character_EquipItem.Text = "Equip Item";
            this.btn_Character_EquipItem.UseVisualStyleBackColor = false;
            // 
            // btn_Character_UseConsumable
            // 
            this.btn_Character_UseConsumable.BackColor = System.Drawing.Color.White;
            this.btn_Character_UseConsumable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Character_UseConsumable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_Character_UseConsumable.ForeColor = System.Drawing.Color.Black;
            this.btn_Character_UseConsumable.Location = new System.Drawing.Point(183, 22);
            this.btn_Character_UseConsumable.Name = "btn_Character_UseConsumable";
            this.btn_Character_UseConsumable.Size = new System.Drawing.Size(150, 30);
            this.btn_Character_UseConsumable.TabIndex = 1;
            this.btn_Character_UseConsumable.Text = "Use Consumable";
            this.btn_Character_UseConsumable.UseVisualStyleBackColor = false;
            this.btn_Character_UseConsumable.Click += new System.EventHandler(this.btn_Character_UseConsumable_Click);
            // 
            // btn_Character_Attack
            // 
            this.btn_Character_Attack.BackColor = System.Drawing.Color.White;
            this.btn_Character_Attack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Character_Attack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_Character_Attack.ForeColor = System.Drawing.Color.Black;
            this.btn_Character_Attack.Location = new System.Drawing.Point(14, 22);
            this.btn_Character_Attack.Name = "btn_Character_Attack";
            this.btn_Character_Attack.Size = new System.Drawing.Size(150, 30);
            this.btn_Character_Attack.TabIndex = 0;
            this.btn_Character_Attack.Text = "Attack";
            this.btn_Character_Attack.UseVisualStyleBackColor = false;
            // 
            // FrameTime
            // 
            this.FrameTime.Interval = 33;
            this.FrameTime.Tick += new System.EventHandler(this.FrameTime_Tick);
            // 
            // btn_Character_Save
            // 
            this.btn_Character_Save.BackColor = System.Drawing.Color.White;
            this.btn_Character_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Character_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_Character_Save.ForeColor = System.Drawing.Color.Black;
            this.btn_Character_Save.Location = new System.Drawing.Point(350, 60);
            this.btn_Character_Save.Name = "btn_Character_Save";
            this.btn_Character_Save.Size = new System.Drawing.Size(150, 30);
            this.btn_Character_Save.TabIndex = 7;
            this.btn_Character_Save.Text = "Save Character";
            this.btn_Character_Save.UseVisualStyleBackColor = false;
            this.btn_Character_Save.Click += new System.EventHandler(this.btn_Character_Save_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1099, 625);
            this.Controls.Add(this.grpbox_Character_Actions);
            this.Controls.Add(this.grpbox_FloorItems);
            this.Controls.Add(this.grpbox_MonsterInfo);
            this.Controls.Add(this.gropbox_New_Character);
            this.Controls.Add(this.gropbox_Character_Info);
            this.Controls.Add(this.grpbox_LogIn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "RPG";
            this.grpbox_LogIn.ResumeLayout(false);
            this.grpbox_LogIn.PerformLayout();
            this.gropbox_Character_Info.ResumeLayout(false);
            this.gropbox_Character_Info.PerformLayout();
            this.gropbox_New_Character.ResumeLayout(false);
            this.gropbox_New_Character.PerformLayout();
            this.grpbox_MonsterInfo.ResumeLayout(false);
            this.grpbox_MonsterInfo.PerformLayout();
            this.grpbox_FloorItems.ResumeLayout(false);
            this.grpbox_Character_Actions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpbox_LogIn;
        private System.Windows.Forms.Button btn_LogIn;
        private System.Windows.Forms.TextBox txtbox_LogIn_Name;
        private System.Windows.Forms.Label lbl_Character_Name;
        private System.Windows.Forms.Label lbl_Character_ExpProgress;
        private System.Windows.Forms.Label lbl_Character_PhysAttack;
        private System.Windows.Forms.Label lbl_Character_PhysDefence;
        private System.Windows.Forms.Label lbl_Character_MagicAttack;
        private System.Windows.Forms.Label lbl_Character_MagicDefence;
        private System.Windows.Forms.Label lbl_Character_HealthPoints;
        private System.Windows.Forms.Label lbl_Character_ManaPoints;
        private System.Windows.Forms.ListBox lstbox_Character_Kit;
        private System.Windows.Forms.ListBox lstbox_Character_Inventory;
        private System.Windows.Forms.GroupBox gropbox_Character_Info;
        private System.Windows.Forms.GroupBox gropbox_New_Character;
        private System.Windows.Forms.TextBox txtbox_NewCharacter_Name;
        private System.Windows.Forms.Label lbl_NewCharacter_Profession;
        private System.Windows.Forms.Label lbl_NewCharacter_Name;
        private System.Windows.Forms.ListBox lstbox_NewCharacter_Profession;
        private System.Windows.Forms.Button btn_NewCharacter_Cancel;
        private System.Windows.Forms.Button btn_NewCharacter_Create;
        private System.Windows.Forms.Label lbl_LogIn_Name;
        private System.Windows.Forms.GroupBox grpbox_MonsterInfo;
        private System.Windows.Forms.Label lbl_Monster_HealthPoints;
        private System.Windows.Forms.Label lbl_Monster_Name;
        private System.Windows.Forms.Label lbl_Monster_MagicDefence;
        private System.Windows.Forms.Label lbl_Monster_MagicAttack;
        private System.Windows.Forms.Label lbl_Monster_PhysDefence;
        private System.Windows.Forms.Label lbl_Monster_PhysAttack;
        private System.Windows.Forms.GroupBox grpbox_FloorItems;
        private System.Windows.Forms.ListBox lstbox_FloorItems;
        private System.Windows.Forms.GroupBox grpbox_Character_Actions;
        private System.Windows.Forms.Button btn_Character_EquipItem;
        private System.Windows.Forms.Button btn_Character_UseConsumable;
        private System.Windows.Forms.Button btn_Character_Attack;
        private System.Windows.Forms.Button btn_Character_RemoveItem;
        private System.Windows.Forms.Button btn_Character_DropItem;
        private System.Windows.Forms.Button btn_Character_PickUpItem;
        private System.Windows.Forms.Timer FrameTime;
        private System.Windows.Forms.Button btn_LogIn_CreateNew;
        private System.Windows.Forms.Button btn_Character_Save;
    }
}

