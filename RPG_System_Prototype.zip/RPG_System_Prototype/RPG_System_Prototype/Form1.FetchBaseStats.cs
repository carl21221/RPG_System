﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RPG_System_Prototype
{
    public partial class Form1
    {
        public string[] GetBaseStatsAsStringArray(string profession, int level)
        {
            string fileDirectory =
                @"D:\Visual Studio Projects\Old School RPG System\oldschoolrpgsystem\oldschoolrpgsystem\data\professionbasestats.txt";
            List<string> lineArray = new List<string>();
            StreamReader reader = new StreamReader(fileDirectory);
            bool professionIsFound = false;
            bool levelIsFound = false;
            //Find profession
            do
            {
                if (reader.ReadLine().StartsWith(profession))
                {
                    professionIsFound = true;
                    break;
                }
            } while (!reader.EndOfStream);

            //Find Level line
            string currentLine = "";
            if (professionIsFound)
            {

                do
                {
                    currentLine = reader.ReadLine();

                    if (currentLine.StartsWith(level.ToString()))
                    {
                        levelIsFound = true;
                        break;
                    }

                } while (!reader.EndOfStream);
            }

            if (professionIsFound && levelIsFound)
            {
                string[] baseStatsAsArray = currentLine.Split(',');
                return baseStatsAsArray;
            }
            else
            {
                string[] emptyArray = { "0", "0", "0", "0", "0", "0", "0", "0" };
                return emptyArray;
            }

        }
        public int[] GetBaseStatsAsIntArray(string profession, int level)
        {
            string fileDirectory =
                @"D:\Visual Studio Projects\Old School RPG System\oldschoolrpgsystem\oldschoolrpgsystem\data\professionbasestats.txt";
            List<string> lineArray = new List<string>();
            StreamReader reader = new StreamReader(fileDirectory);
            bool professionIsFound = false;
            bool levelIsFound = false;
            //Find profession
            do
            {
                if (reader.ReadLine().StartsWith(profession))
                {
                    professionIsFound = true;
                    break;
                }
            } while (!reader.EndOfStream);

            //Find Level line
            string currentLine = "";
            if (professionIsFound)
            {

                do
                {
                    currentLine = reader.ReadLine();

                    if (currentLine.StartsWith(level.ToString()))
                    {
                        levelIsFound = true;
                        break;
                    }

                } while (!reader.EndOfStream);
            }

            if (professionIsFound && levelIsFound)
            {
                string[] baseStatsAsArray = currentLine.Split(',');
                int[] intArray = { 0, 0, 0, 0, 0, 0, 0, 0 };

                for (int i = 0; i <= baseStatsAsArray.Length; i++)
                {
                    intArray[i] = int.Parse(baseStatsAsArray[i]);
                }


                return intArray;
            }
            else
            {
                int[] emptyArray = { 0, 0, 0, 0, 0, 0, 0, 0 };
                return emptyArray;
            }
        }
    }
}