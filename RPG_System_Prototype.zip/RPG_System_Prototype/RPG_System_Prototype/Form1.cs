﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPG_System_Prototype
{
    public partial class Form1 : Form
    {
        Character playerCharacter;
        Monster monster1;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btn_Character_UseConsumable_Click(object sender, EventArgs e)
        {

        }

        private void btn_LogIn_Click(object sender, EventArgs e)
        {
            if(txtbox_LogIn_Name.Text != "") //make sure there is text in the box
            {
                string[] foundAttribs = GetCharAttributesFromFile(txtbox_LogIn_Name.Text);

                if(foundAttribs[0] == "")
                {
                    MessageBox.Show("Character records not found");
                }
                else
                {
                    playerCharacter = new Character(foundAttribs[0], foundAttribs[1], int.Parse(foundAttribs[2]), int.Parse(foundAttribs[3]), int.Parse(foundAttribs[4]),
                                                    int.Parse(foundAttribs[5]), int.Parse(foundAttribs[6]), int.Parse(foundAttribs[7]), int.Parse(foundAttribs[8]),
                                                    int.Parse(foundAttribs[9]), int.Parse(foundAttribs[10]), int.Parse(foundAttribs[11]));
                    //create a list of items using the characters inventory list
                    //add that to the character

                    DisableLogInBox();
                    
                    EnableCharacterInfoBox();
                    EnableCharacterActionsBox();
                    EnableMonsterInfoBox();
                    UpdateCharacterInfoGUI();
                }                        

            }
        }

        private void btn_LogIn_CreateNew_Click(object sender, EventArgs e)
        {
            EnableNewCharacterBox();
            DisableLogInBox();
        }
        private void btn_NewCharacter_Cancel_Click(object sender, EventArgs e)
        {
            DisableNewCharacterBox();
            EnableLogInBox();
        }

        private void EnableCharacterInfoBox()
        {
            gropbox_Character_Info.Visible = true;
        }
        private void EnableCharacterActionsBox()
        {
            grpbox_Character_Actions.Visible = true;
        }

        private void DisableCharacterInfoBox()
        {
            gropbox_Character_Info.Visible = false;
        }
        private void DisableCharacterActionsBox()
        {
            grpbox_Character_Actions.Visible = false;
        }

        private void EnableMonsterInfoBox()
        {
            grpbox_MonsterInfo.Visible = true;
        }

        private void DisableMonsterInfoBox()
        {
            grpbox_MonsterInfo.Visible = false;
        }

        public void EnableNewCharacterBox()
        {
            gropbox_New_Character.Visible = true;
        }
        public void DisableNewCharacterBox()
        {
            txtbox_NewCharacter_Name.Text = "";
            lstbox_NewCharacter_Profession.SelectedItem = null;
            gropbox_New_Character.Visible = false;
        }

        public void EnableLogInBox()
        {
            grpbox_LogIn.Visible = true;
        }
        public void DisableLogInBox()
        {
            txtbox_LogIn_Name.Text = "";
            grpbox_LogIn.Visible = false;
        }
        public void EnableFloorItemsBox()
        {
            lstbox_FloorItems.Visible = true;
        }
        public void DisableFloorItemsBox()
        {
            lstbox_FloorItems.SelectedItem = null;
            lstbox_FloorItems.Visible = false;
        }

        private void btn_NewCharacter_Create_Click(object sender, EventArgs e)
        {
            string newCharName = "";
            string newCharProf = "";

            if (txtbox_NewCharacter_Name.Text != "")
            {
                if (txtbox_NewCharacter_Name.Text.Length <= 3)
                {
                    newCharName = txtbox_NewCharacter_Name.Text;
                    newCharProf = lstbox_NewCharacter_Profession.Text;
                }
                else
                {
                    MessageBox.Show("Name needs to be 4 or more characters long");
                    txtbox_NewCharacter_Name.Text = "";
                    lstbox_NewCharacter_Profession.SelectedItem = null;
                }
            }
            else
            {
                MessageBox.Show("Please type a name");
                lstbox_NewCharacter_Profession.SelectedItem = null;
            }

            if (lstbox_NewCharacter_Profession.SelectedItem != null)
            {
                newCharProf = lstbox_NewCharacter_Profession.Text;
            }
            else
            {
                MessageBox.Show("Please choose a profession");
            }
        
            if (newCharName != "" && newCharProf != "")
            {
                
            }
        }

        public void UpdateCharacterInfoGUI()
        {
            if (playerCharacter != null)
            {
                lbl_Character_Name.Text = "Name: "+ playerCharacter.GetName();
                lbl_Character_ExpProgress.Text = "EXP: " + playerCharacter.GetCurrentExperience().ToString() + " / " + playerCharacter.GetExperienceGoal().ToString();
                lbl_Character_HealthPoints.Text = "HP: " + playerCharacter.GetHealthPoints().ToString() + " / " + playerCharacter.GetMaxHealthPoints().ToString();
                lbl_Character_HealthPoints.Text = "MP: " + playerCharacter.GetManaPoints().ToString() + " / " + playerCharacter.GetMaxManaPoints().ToString();
                lbl_Character_PhysAttack.Text = "Physical Attack: " + playerCharacter.GetPhysicalAttack().ToString();
                lbl_Character_PhysDefence.Text = "Physical Defence: " + playerCharacter.GetPhysicalDefence().ToString();
                lbl_Character_MagicAttack.Text = "Magic Attack: " + playerCharacter.GetMagicAttack().ToString();
                lbl_Character_MagicDefence.Text = "Magic Defence: " + playerCharacter.GetMagicDefence().ToString();
            }
            else
            {
                lbl_Character_Name.Text = "Character Not Loaded";
            }
        }

        public void UpdateMonsterInfoGUI()
        {

        }

        private void FrameTime_Tick(object sender, EventArgs e)
        {
            UpdateCharacterInfoGUI();
            UpdateMonsterInfoGUI();
        }

        private void btn_Character_Save_Click(object sender, EventArgs e)
        {
            if (playerCharacter != null)
            {
                SaveCharacterToFile(playerCharacter);
                MessageBox.Show("Character saved!");
            }
        }
    }
}
