﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_System_Prototype
{
    public class Monster // : Monobehavior
    {
        // variables which load from database

        // Name,AttackType,Level,PhysAttack,MagAttack,PhysDef,MagDef,HP,MaxHP,walkspeed,attackspeed

        private string name;
        private string attackType; //either "Melee" or "Ranged"
        private int level = 1;
        private int physAttack = 0;
        private int magAttack = 0;
        private int physDefense = 0;
        private int magDefense = 0;
        private int maxHealthPoints = 500;
        private int currentHealthPoints = 500;

        private float experienceReward = 250;

        private int walkSpeed;
        private int attackSpeed;

        // variables which load during runtime

        Character currentPlayerTarget = null;

        bool isIdle = true;
        bool isAggressive = false;
        bool isDefensive = false;

        //Constructors

        public Monster(string monsterName, int level, int physAttack, int magAttack, int physDef, int magDef, 
                       int health, float experienceReward, int walkSpeed, int attackSpeed, string attackType)
        {
            if(monsterName != "")
                this.name = monsterName;
            else
                throw new System.ArgumentException("Name cannot be empty", "original");

            if (level > 0)
                this.level = level;
            else
                throw new System.ArgumentException("Level must be greater than 0", "original");
            this.attackType = attackType;

            this.physAttack = physAttack;
            this.magAttack = magAttack;
            this.physDefense = physDef;
            this.magDefense = magDef;

            if(maxHealthPoints > 0)
                this.maxHealthPoints = health;
            else
            throw new System.ArgumentException("Max health must be greater than 0", "original");

            this.currentHealthPoints = health;

            if(experienceReward >= 0)
                this.experienceReward = experienceReward;
            else throw new System.ArgumentException("Experience reward must be greater than 0", "original");

            this.walkSpeed = walkSpeed;
            this.attackSpeed = attackSpeed;
        }

        // Getters and Setters
        public void SetName(string newName) { this.name = newName; }
        public string GetName() { return this.name; }
        public void SetLevel(int newLevel) { this.level = newLevel; }
        public int GetLevel() { return level; }
        public void SetMaxHealth(int newMaxHealth) { maxHealthPoints = newMaxHealth; }
        public int GetMaxHealth() { return maxHealthPoints; }
        public void SetCurrentHealth(int newHealth) { currentHealthPoints = newHealth; }
        public int GetCurrentHealth() { return currentHealthPoints; }
        public void SetExperienceReward(float newExperienceReward) { this.experienceReward = newExperienceReward; }
        public float GetExperienceReward() { return experienceReward; }

        public int GetPhysicalAttack() { return this.physAttack; }
        public void SetPhysicalAttack(int newPhysAttack) { this.physAttack = newPhysAttack; }
        public int GetMagicAttack() { return this.magAttack; }
        public void SetMagicAttack(int newMagAttack) { this.magAttack = newMagAttack; }
        public int GetPhysicalDefense() { return this.physDefense; }
        public void SetPhysicalDefense(int newPhysDefense) { this.physDefense = newPhysDefense; }
        public int GetMagicDefense() { return this.magDefense; }
        public void SetMagicDefense(int newMagDefense) { this.magDefense = newMagDefense; }
        public void SetWalkSpeed(int newWalkSpeed) { this.walkSpeed = newWalkSpeed; }
        public int GetWalkSpeed() { return walkSpeed; }
        public void SetAttackSpeed(int newAttackSpeed) { this.attackSpeed = newAttackSpeed; }
        public int GetAttackSpeed() { return attackSpeed; }
        public void SetPlayerTarget(Character player) { this.currentPlayerTarget = player; }
        public string GetAttackType() { return attackType; }
        public void SetAttackType(string attackType) { this.attackType = attackType; }
        public Character GetCurrentPlayerTarget() { return currentPlayerTarget; }
    
        // Other Methods

        public void TakeDamage(int damageToTake)
        {
            if(damageToTake >= 0)
                this.currentHealthPoints = currentHealthPoints - damageToTake;
            else
                throw new System.ArgumentException("Damage must be a positive value", "original");
        }
        public void RemovePlayerTarget() { currentPlayerTarget = null; }
        public void RestoreHealth() { currentHealthPoints = maxHealthPoints; }
    }
}
