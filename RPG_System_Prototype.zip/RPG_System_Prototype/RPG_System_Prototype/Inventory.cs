﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_System_Prototype
{
    public class Inventory
    {

        // Variables 
        private int maxCapacity = 40;
        private List<Item> itemCollection = new List<Item>();

        public Inventory() //For initialising an empty inventory
        {

        }
        public Inventory(List<string> savedItemNames) //To initialise an inventory with items already in
        {
            InitialiseInventoryWithStringArray(savedItemNames);
        }

        public void InitialiseInventoryWithStringArray(List<string> savedItemNames)
        {
            foreach(string s in savedItemNames)
            {
                //Find the item in data folder, get its stats and create a new item, adding it to itemCollection
            }
        }
        public int GetMaxCapacity() { return this.maxCapacity; }
        public List<Item> GetInventoryAsList() { return itemCollection; }
        public void SetMaxCapacity(int newMax) { this.maxCapacity = newMax; }
        public int GetItemCount() { return itemCollection.Count(); }
        public void AddItemToInventory(Item i)
        {
            if (itemCollection.Count() < maxCapacity)
            {
                itemCollection.Add(i);
            }
            else
            {
                //Dont Add
            }
        }
        public void AddListToInventory(List<Item> listToMerge)
        {
            foreach(Item i in listToMerge)
            {
                itemCollection.Add(i);
            }
        }
        public Item GetItemByIndex(int index)
        {
            return itemCollection[index];
        }
        public Item GetItem(Item itemToGet)
        {
            foreach  (Item i in itemCollection)
            {
                if (itemToGet.GetName() == i.GetName())
                {
                    return i;
                }
            }
            return null;
        }
        public void RemoveItem(Item itemToRemove)
        {
            foreach (Item i in itemCollection)
            {
                if (itemToRemove.GetName() == i.GetName())
                {
                    itemCollection.Remove(i);
                    break;
                }
            }
        }
        public void ClearInventory()
        {
            itemCollection.Clear();
        }

        //questions to ask jamie
        // If both my Wearable and Consumable items inherit from the Base "Item" class, can I add Wearables and Consumables to a List<Item>?
    }
}
