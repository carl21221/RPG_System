﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;



namespace oldschoolrpgsystem
{
    public partial class Form1 : Form
    {
        Character c1;
        Monster m1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            grpbox_NewCharacter.Visible = false;
        }

        private void btn_LoadCharacter_Click(object sender, EventArgs e)
        {
            if (txtbox_NameToLoad.Text != "")
            {
                string[] charAttribs;
                charAttribs = GetCharAttributesFromFile(txtbox_NameToLoad.Text);
                if (charAttribs != null)
                {
                    c1 = new Character(charAttribs[0], charAttribs[1], int.Parse(charAttribs[2]), int.Parse(charAttribs[3]), int.Parse(charAttribs[4]),
                                       int.Parse(charAttribs[5]), int.Parse(charAttribs[6]), int.Parse(charAttribs[7]), int.Parse(charAttribs[8]), int.Parse(charAttribs[9]),
                                       int.Parse(charAttribs[10]), int.Parse(charAttribs[11]));
                    UpdateLabels(c1);
                }
                else
                    MessageBox.Show("WARNING: Character Not Loaded Successfully");
            }
            else 
                MessageBox.Show("Please type your character name in the box");
        }




        public void UpdateLabels(Character c)
        {
            if (c != null) //make sure there is an object in the variable first
            {
                lbl_Player1_Name.Text = c.GetName();
                lbl_Player1_Level.Text = "Level: " + c.GetCurrentLevel().ToString() + " (Experience: " + c.GetCurrentExperience().ToString() + " / " + c.GetExperienceGoal().ToString() + ")";

                lbl_Player1_Health.Text = "Health: " + c.GetHealthPoints().ToString() + " / " + c.GetMaxHealthPoints().ToString();
                lbl_Player1_Mana.Text = "Mana: " + c.GetManaPoints().ToString() + " / " + c.GetMaxManaPoints().ToString();

                lbl_Player1_physdam.Text = "Physical Damage: " + c.GetPhysicalAttack().ToString();
                lbl_Player1_PhysDef.Text = "Physical Defence: " + c.GetPhysicalDefence().ToString();
                lbl_Player1_MagicDamage.Text = "Magic Damage: " + c.GetMagicAttack().ToString();
                lbl_Player1_MagicDef.Text = "Magic Defence: " + c.GetMagicDefence().ToString();


                //Colour Alterations
                if(c.IsHealthIncreasing() == true)
                    lbl_Player1_Health.ForeColor = System.Drawing.Color.Red;
                else if (c.IsHealthIncreasing() == false)
                    lbl_Player1_Health.ForeColor = System.Drawing.Color.White;

                if (c.IsManaIncreasing() == true)
                    lbl_Player1_Mana.ForeColor = System.Drawing.Color.Blue;
                else if (c.IsManaIncreasing() == false)
                    lbl_Player1_Mana.ForeColor = System.Drawing.Color.White;
            }
        }

        private void btn_TakeDamage_Click(object sender, EventArgs e)
        {
            if (c1 != null)
            {
                c1.DecreaseHealthPoints(25);
                UpdateLabels(c1);
            }
        }

        private void btn_UseMagic_Click(object sender, EventArgs e)
        {
            if (c1 != null)
            {
                c1.DecreaseManaPoints(3);
                UpdateLabels(c1);
            }
        }

        private void btn_UseHealthPotion_Click(object sender, EventArgs e)
        {
            if (c1 != null)
            {
                if (c1.GetHealthPoints() < c1.GetMaxHealthPoints()) //If health is not full
                {
                    c1.SetHealthIncreasing(true); //Set that a potion has been used
                    c1.SetHealthIncreaseTimer(10); //Sets the potion timer to 10
                }
                else
                    MessageBox.Show("Health is already at maximum."); // otherwise if health is full, don't use potion and notify the player

                UpdateLabels(c1);
            }
        }

        private void btn_UseManaPotion_Click(object sender, EventArgs e)
        {
            if (c1 != null)
            {
                if (c1.GetManaPoints() < c1.GetMaxManaPoints())
                {
                    c1.SetManaIncreasing(true); //Set that a potion has been used
                    c1.SetManaIncreaseTimer(10); //Sets the potion timer to 10
                }
                else
                    MessageBox.Show("Mana is already at maximum.");  // otherwise if mana is full, don't use potion and notify the player

                UpdateLabels(c1);
            }
        }

        private void tickTimer_Tick(object sender, EventArgs e)
        {
            if (c1 != null) //Check if there is an object in c1 before doing anything
            {
                if (c1.IsHealthIncreasing() == true) //If a potion has been used
                {
                    if (c1.GetHealthIncreaseTimer() != 0) // and health timer isnt at 0
                    {
                        c1.IncreaseHealthPoints(10); //Increase health of player by 10hp
                        c1.SetHealthIncreaseTimer(c1.GetHealthIncreaseTimer() - 1); //take 1 from the timer
                    }

                    if (c1.GetHealthIncreaseTimer() == 0) // If the timer is now at 0
                    {
                        c1.SetHealthIncreasing(false); //turn off the potion effects
                    }
                }

                if (c1.IsManaIncreasing() == true) //If a potion has been used
                {
                    if (c1.GetManaIncreaseTimer() != 0) // and mana timer isnt at 0
                    {
                        c1.IncreaseManaPoints(10); //Increase mana of player by 10mp
                        c1.SetManaIncreaseTimer(c1.GetManaIncreaseTimer() - 1); //take 1 from the timer
                    }

                    if (c1.GetManaIncreaseTimer() == 0) // If the timer is now at 0
                    {
                        c1.SetManaIncreasing(false); //turn off the potion effects
                    }
                }

            }
            UpdateLabels(c1);
        }

        private void btn_Player1_Attack_Click(object sender, EventArgs e)
        {

        }

        private void btn_deleteChar_Click(object sender, EventArgs e)
        {
            if (txtbox_NameToLoad.Text != "")
            {
                if (GetCharAttributesFromFile(txtbox_NameToLoad.Text) != null)
                {
                    DeleteCharAttributesFromFile(c1);
                    MessageBox.Show("Character Entry has been deleted");
                }
                else
                {
                    MessageBox.Show("Character Not Found");
                }
            }
            else
            {
                MessageBox.Show("Text box is empty");
            }
        }

        private void btn_SaveChar_Click(object sender, EventArgs e)
        {
            if (txtbox_NameToLoad.Text != "")
            {
                if (c1 != null)
                {
                    if (GetCharAttributesFromFile(c1.GetName()) != null) // if name already exists
                    {
                        // overwrite
                        MessageBox.Show("Character is overwritten");
                    }
                    else
                    {
                        SaveCharAttributesToFile(c1); // adds a new line to the char attrib file
                        MessageBox.Show("New Character Saved");
                    }
                }
            }
        }

        private void btn_CreateNewChar_Click(object sender, EventArgs e)
        {
            btn_CreateNewChar.Visible = false;
            grpbox_NewCharacter.Visible = true;

            btn_LoadCharacter.Enabled = false;
            txtbox_NameToLoad.Enabled = false;
        }

        private void btn_CancelNewCharacter_Click(object sender, EventArgs e)
        {
            btn_CreateNewChar.Visible = true;
            grpbox_NewCharacter.Visible = false;
            btn_LoadCharacter.Enabled = true;
            txtbox_NameToLoad.Enabled = true;

        }

        private void btn_SubmitNewCharacter_Click(object sender, EventArgs e)
        {
            if(txtbox_NewCharacterName.Text.Length < 6)
            {
                MessageBox.Show("Name must be at least 6 character long");
            }
            else if (listbox_ProfessionList.SelectedItem == null)
            {
                MessageBox.Show("Please choose profession");
            }
            else 
            {
                CreateNewCharInFile(txtbox_NewCharacterName.Text, listbox_ProfessionList.SelectedItem.ToString());
            }
        }

        private void btn_LoadNewMonster_Click(object sender, EventArgs e)
        {
            if(txtbox_MonsterNameInput.Text != "")
            {
                string[] newMonsterStats = GetMonsterStatsAsStringArray(txtbox_MonsterNameInput.Text);
                m1 = new Monster(newMonsterStats[0], int.Parse(newMonsterStats[1]), int.Parse(newMonsterStats[2]), int.Parse(newMonsterStats[3]), int.Parse(newMonsterStats[4]), 
                      int.Parse(newMonsterStats[5]), int.Parse(newMonsterStats[6]), int.Parse(newMonsterStats[7]), int.Parse(newMonsterStats[8]), int.Parse(newMonsterStats[9])
                      , newMonsterStats[10]);
                lbl_MonsterName.Text = m1.GetName();
                lbl_MonsterHealth.Text = m1.GetCurrentHealth().ToString();
                lbl_MonsterLevel.Text = m1.GetLevel().ToString();
            }
            else
            {
                MessageBox.Show("Please type a monster name first!");
            }
        }
    }
}

