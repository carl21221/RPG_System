﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oldschoolrpgsystem
{
    abstract public class Item
    {
        //common variables
        protected string name;
        protected int price;
        protected string uiImageFilePath;
         //Constructors
        public Item()
        {
            this.name = "";
            this.price = 0;
        }

        public Item(string name, int price, string uiImageFilePath)
        {
            this.name = name;
            this.price = price;
            this.uiImageFilePath = uiImageFilePath;
        }

        public string GetName() { return name; }
        public int GetPrice() { return price; }
        public string GetUIImageFilePath() { return uiImageFilePath; }
    }
}
