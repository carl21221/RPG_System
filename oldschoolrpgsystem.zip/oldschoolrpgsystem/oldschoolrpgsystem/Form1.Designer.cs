﻿namespace oldschoolrpgsystem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_Player1_Name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Player1_Health = new System.Windows.Forms.Label();
            this.lbl_Player1_Mana = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_Player1_Level = new System.Windows.Forms.Label();
            this.lbl_Player1_physdam = new System.Windows.Forms.Label();
            this.lbl_Player1_PhysDef = new System.Windows.Forms.Label();
            this.lbl_Player1_MagicDamage = new System.Windows.Forms.Label();
            this.lbl_Player1_MagicDef = new System.Windows.Forms.Label();
            this.btn_LoadCharacter = new System.Windows.Forms.Button();
            this.btn_TakeDamage = new System.Windows.Forms.Button();
            this.btn_UseMagic = new System.Windows.Forms.Button();
            this.btn_UseHealthPotion = new System.Windows.Forms.Button();
            this.btn_UseManaPotion = new System.Windows.Forms.Button();
            this.tickTimer = new System.Windows.Forms.Timer(this.components);
            this.btn_Player1_Attack = new System.Windows.Forms.Button();
            this.txtbox_NameToLoad = new System.Windows.Forms.TextBox();
            this.btn_deleteChar = new System.Windows.Forms.Button();
            this.btn_SaveChar = new System.Windows.Forms.Button();
            this.grpbox_NewCharacter = new System.Windows.Forms.GroupBox();
            this.btn_CancelNewCharacter = new System.Windows.Forms.Button();
            this.btn_SubmitNewCharacter = new System.Windows.Forms.Button();
            this.lbl_NewCharacterProfession = new System.Windows.Forms.Label();
            this.lbl_NewCharacterName = new System.Windows.Forms.Label();
            this.listbox_ProfessionList = new System.Windows.Forms.ListBox();
            this.txtbox_NewCharacterName = new System.Windows.Forms.TextBox();
            this.btn_CreateNewChar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.grpbox_Monster = new System.Windows.Forms.GroupBox();
            this.lbl_MonsterName = new System.Windows.Forms.Label();
            this.lbl_MonsterLevel = new System.Windows.Forms.Label();
            this.lbl_MonsterHealth = new System.Windows.Forms.Label();
            this.btn_LoadNewMonster = new System.Windows.Forms.Button();
            this.txtbox_MonsterNameInput = new System.Windows.Forms.TextBox();
            this.grpbox_NewCharacter.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpbox_Monster.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Player1_Name
            // 
            this.lbl_Player1_Name.AutoSize = true;
            this.lbl_Player1_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Player1_Name.ForeColor = System.Drawing.Color.White;
            this.lbl_Player1_Name.Location = new System.Drawing.Point(304, 13);
            this.lbl_Player1_Name.Name = "lbl_Player1_Name";
            this.lbl_Player1_Name.Size = new System.Drawing.Size(214, 24);
            this.lbl_Player1_Name.TabIndex = 1;
            this.lbl_Player1_Name.Text = "Character Not Loaded";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(304, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Stats:";
            // 
            // lbl_Player1_Health
            // 
            this.lbl_Player1_Health.AutoSize = true;
            this.lbl_Player1_Health.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_Player1_Health.ForeColor = System.Drawing.Color.White;
            this.lbl_Player1_Health.Location = new System.Drawing.Point(314, 96);
            this.lbl_Player1_Health.Name = "lbl_Player1_Health";
            this.lbl_Player1_Health.Size = new System.Drawing.Size(63, 20);
            this.lbl_Player1_Health.TabIndex = 4;
            this.lbl_Player1_Health.Text = "Health:";
            // 
            // lbl_Player1_Mana
            // 
            this.lbl_Player1_Mana.AutoSize = true;
            this.lbl_Player1_Mana.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_Player1_Mana.ForeColor = System.Drawing.Color.White;
            this.lbl_Player1_Mana.Location = new System.Drawing.Point(314, 116);
            this.lbl_Player1_Mana.Name = "lbl_Player1_Mana";
            this.lbl_Player1_Mana.Size = new System.Drawing.Size(55, 20);
            this.lbl_Player1_Mana.TabIndex = 5;
            this.lbl_Player1_Mana.Text = "Mana:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(562, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 6;
            // 
            // lbl_Player1_Level
            // 
            this.lbl_Player1_Level.AutoSize = true;
            this.lbl_Player1_Level.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_Player1_Level.ForeColor = System.Drawing.Color.White;
            this.lbl_Player1_Level.Location = new System.Drawing.Point(314, 41);
            this.lbl_Player1_Level.Name = "lbl_Player1_Level";
            this.lbl_Player1_Level.Size = new System.Drawing.Size(54, 20);
            this.lbl_Player1_Level.TabIndex = 7;
            this.lbl_Player1_Level.Text = "Level:";
            // 
            // lbl_Player1_physdam
            // 
            this.lbl_Player1_physdam.AutoSize = true;
            this.lbl_Player1_physdam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_Player1_physdam.ForeColor = System.Drawing.Color.White;
            this.lbl_Player1_physdam.Location = new System.Drawing.Point(314, 148);
            this.lbl_Player1_physdam.Name = "lbl_Player1_physdam";
            this.lbl_Player1_physdam.Size = new System.Drawing.Size(145, 20);
            this.lbl_Player1_physdam.TabIndex = 8;
            this.lbl_Player1_physdam.Text = "Physical Damage:";
            // 
            // lbl_Player1_PhysDef
            // 
            this.lbl_Player1_PhysDef.AutoSize = true;
            this.lbl_Player1_PhysDef.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_Player1_PhysDef.ForeColor = System.Drawing.Color.White;
            this.lbl_Player1_PhysDef.Location = new System.Drawing.Point(314, 172);
            this.lbl_Player1_PhysDef.Name = "lbl_Player1_PhysDef";
            this.lbl_Player1_PhysDef.Size = new System.Drawing.Size(145, 20);
            this.lbl_Player1_PhysDef.TabIndex = 9;
            this.lbl_Player1_PhysDef.Text = "Physical Defence:";
            // 
            // lbl_Player1_MagicDamage
            // 
            this.lbl_Player1_MagicDamage.AutoSize = true;
            this.lbl_Player1_MagicDamage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_Player1_MagicDamage.ForeColor = System.Drawing.Color.White;
            this.lbl_Player1_MagicDamage.Location = new System.Drawing.Point(314, 196);
            this.lbl_Player1_MagicDamage.Name = "lbl_Player1_MagicDamage";
            this.lbl_Player1_MagicDamage.Size = new System.Drawing.Size(127, 20);
            this.lbl_Player1_MagicDamage.TabIndex = 10;
            this.lbl_Player1_MagicDamage.Text = "Magic Damage:";
            // 
            // lbl_Player1_MagicDef
            // 
            this.lbl_Player1_MagicDef.AutoSize = true;
            this.lbl_Player1_MagicDef.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_Player1_MagicDef.ForeColor = System.Drawing.Color.White;
            this.lbl_Player1_MagicDef.Location = new System.Drawing.Point(314, 220);
            this.lbl_Player1_MagicDef.Name = "lbl_Player1_MagicDef";
            this.lbl_Player1_MagicDef.Size = new System.Drawing.Size(127, 20);
            this.lbl_Player1_MagicDef.TabIndex = 11;
            this.lbl_Player1_MagicDef.Text = "Magic Defence:";
            // 
            // btn_LoadCharacter
            // 
            this.btn_LoadCharacter.BackColor = System.Drawing.Color.White;
            this.btn_LoadCharacter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LoadCharacter.ForeColor = System.Drawing.Color.Black;
            this.btn_LoadCharacter.Location = new System.Drawing.Point(17, 66);
            this.btn_LoadCharacter.Name = "btn_LoadCharacter";
            this.btn_LoadCharacter.Size = new System.Drawing.Size(248, 37);
            this.btn_LoadCharacter.TabIndex = 12;
            this.btn_LoadCharacter.Text = "Load Character";
            this.btn_LoadCharacter.UseVisualStyleBackColor = false;
            this.btn_LoadCharacter.Click += new System.EventHandler(this.btn_LoadCharacter_Click);
            // 
            // btn_TakeDamage
            // 
            this.btn_TakeDamage.BackColor = System.Drawing.Color.White;
            this.btn_TakeDamage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_TakeDamage.Location = new System.Drawing.Point(308, 326);
            this.btn_TakeDamage.Name = "btn_TakeDamage";
            this.btn_TakeDamage.Size = new System.Drawing.Size(210, 23);
            this.btn_TakeDamage.TabIndex = 13;
            this.btn_TakeDamage.Text = "Take Damage";
            this.btn_TakeDamage.UseVisualStyleBackColor = false;
            this.btn_TakeDamage.Click += new System.EventHandler(this.btn_TakeDamage_Click);
            // 
            // btn_UseMagic
            // 
            this.btn_UseMagic.BackColor = System.Drawing.Color.White;
            this.btn_UseMagic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UseMagic.Location = new System.Drawing.Point(417, 256);
            this.btn_UseMagic.Name = "btn_UseMagic";
            this.btn_UseMagic.Size = new System.Drawing.Size(103, 23);
            this.btn_UseMagic.TabIndex = 14;
            this.btn_UseMagic.Text = "Use Magic";
            this.btn_UseMagic.UseVisualStyleBackColor = false;
            this.btn_UseMagic.Click += new System.EventHandler(this.btn_UseMagic_Click);
            // 
            // btn_UseHealthPotion
            // 
            this.btn_UseHealthPotion.BackColor = System.Drawing.Color.White;
            this.btn_UseHealthPotion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UseHealthPotion.Location = new System.Drawing.Point(417, 285);
            this.btn_UseHealthPotion.Name = "btn_UseHealthPotion";
            this.btn_UseHealthPotion.Size = new System.Drawing.Size(103, 23);
            this.btn_UseHealthPotion.TabIndex = 15;
            this.btn_UseHealthPotion.Text = "Use Health Potion";
            this.btn_UseHealthPotion.UseVisualStyleBackColor = false;
            this.btn_UseHealthPotion.Click += new System.EventHandler(this.btn_UseHealthPotion_Click);
            // 
            // btn_UseManaPotion
            // 
            this.btn_UseManaPotion.BackColor = System.Drawing.Color.White;
            this.btn_UseManaPotion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UseManaPotion.Location = new System.Drawing.Point(308, 285);
            this.btn_UseManaPotion.Name = "btn_UseManaPotion";
            this.btn_UseManaPotion.Size = new System.Drawing.Size(103, 23);
            this.btn_UseManaPotion.TabIndex = 16;
            this.btn_UseManaPotion.Text = "Use Mana Potion";
            this.btn_UseManaPotion.UseVisualStyleBackColor = false;
            this.btn_UseManaPotion.Click += new System.EventHandler(this.btn_UseManaPotion_Click);
            // 
            // tickTimer
            // 
            this.tickTimer.Enabled = true;
            this.tickTimer.Interval = 1000;
            this.tickTimer.Tick += new System.EventHandler(this.tickTimer_Tick);
            // 
            // btn_Player1_Attack
            // 
            this.btn_Player1_Attack.BackColor = System.Drawing.Color.White;
            this.btn_Player1_Attack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Player1_Attack.Location = new System.Drawing.Point(308, 256);
            this.btn_Player1_Attack.Name = "btn_Player1_Attack";
            this.btn_Player1_Attack.Size = new System.Drawing.Size(103, 23);
            this.btn_Player1_Attack.TabIndex = 17;
            this.btn_Player1_Attack.Text = "Attack";
            this.btn_Player1_Attack.UseVisualStyleBackColor = false;
            this.btn_Player1_Attack.Click += new System.EventHandler(this.btn_Player1_Attack_Click);
            // 
            // txtbox_NameToLoad
            // 
            this.txtbox_NameToLoad.Location = new System.Drawing.Point(17, 29);
            this.txtbox_NameToLoad.Name = "txtbox_NameToLoad";
            this.txtbox_NameToLoad.Size = new System.Drawing.Size(248, 26);
            this.txtbox_NameToLoad.TabIndex = 18;
            this.txtbox_NameToLoad.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbox_NameToLoad.WordWrap = false;
            // 
            // btn_deleteChar
            // 
            this.btn_deleteChar.Location = new System.Drawing.Point(409, 544);
            this.btn_deleteChar.Name = "btn_deleteChar";
            this.btn_deleteChar.Size = new System.Drawing.Size(109, 43);
            this.btn_deleteChar.TabIndex = 19;
            this.btn_deleteChar.Text = "Delete Char";
            this.btn_deleteChar.UseVisualStyleBackColor = true;
            this.btn_deleteChar.Click += new System.EventHandler(this.btn_deleteChar_Click);
            // 
            // btn_SaveChar
            // 
            this.btn_SaveChar.Location = new System.Drawing.Point(302, 544);
            this.btn_SaveChar.Name = "btn_SaveChar";
            this.btn_SaveChar.Size = new System.Drawing.Size(103, 43);
            this.btn_SaveChar.TabIndex = 20;
            this.btn_SaveChar.Text = "Save Char";
            this.btn_SaveChar.UseVisualStyleBackColor = true;
            this.btn_SaveChar.Click += new System.EventHandler(this.btn_SaveChar_Click);
            // 
            // grpbox_NewCharacter
            // 
            this.grpbox_NewCharacter.Controls.Add(this.btn_CancelNewCharacter);
            this.grpbox_NewCharacter.Controls.Add(this.btn_SubmitNewCharacter);
            this.grpbox_NewCharacter.Controls.Add(this.lbl_NewCharacterProfession);
            this.grpbox_NewCharacter.Controls.Add(this.lbl_NewCharacterName);
            this.grpbox_NewCharacter.Controls.Add(this.listbox_ProfessionList);
            this.grpbox_NewCharacter.Controls.Add(this.txtbox_NewCharacterName);
            this.grpbox_NewCharacter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.grpbox_NewCharacter.ForeColor = System.Drawing.Color.White;
            this.grpbox_NewCharacter.Location = new System.Drawing.Point(12, 362);
            this.grpbox_NewCharacter.Name = "grpbox_NewCharacter";
            this.grpbox_NewCharacter.Size = new System.Drawing.Size(284, 248);
            this.grpbox_NewCharacter.TabIndex = 21;
            this.grpbox_NewCharacter.TabStop = false;
            this.grpbox_NewCharacter.Text = "New Character";
            // 
            // btn_CancelNewCharacter
            // 
            this.btn_CancelNewCharacter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_CancelNewCharacter.ForeColor = System.Drawing.Color.Black;
            this.btn_CancelNewCharacter.Location = new System.Drawing.Point(142, 170);
            this.btn_CancelNewCharacter.Name = "btn_CancelNewCharacter";
            this.btn_CancelNewCharacter.Size = new System.Drawing.Size(123, 55);
            this.btn_CancelNewCharacter.TabIndex = 23;
            this.btn_CancelNewCharacter.Text = "Cancel";
            this.btn_CancelNewCharacter.UseVisualStyleBackColor = true;
            this.btn_CancelNewCharacter.Click += new System.EventHandler(this.btn_CancelNewCharacter_Click);
            // 
            // btn_SubmitNewCharacter
            // 
            this.btn_SubmitNewCharacter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_SubmitNewCharacter.ForeColor = System.Drawing.Color.Black;
            this.btn_SubmitNewCharacter.Location = new System.Drawing.Point(17, 170);
            this.btn_SubmitNewCharacter.Name = "btn_SubmitNewCharacter";
            this.btn_SubmitNewCharacter.Size = new System.Drawing.Size(123, 55);
            this.btn_SubmitNewCharacter.TabIndex = 23;
            this.btn_SubmitNewCharacter.Text = "Create Character";
            this.btn_SubmitNewCharacter.UseVisualStyleBackColor = true;
            this.btn_SubmitNewCharacter.Click += new System.EventHandler(this.btn_SubmitNewCharacter_Click);
            // 
            // lbl_NewCharacterProfession
            // 
            this.lbl_NewCharacterProfession.AutoSize = true;
            this.lbl_NewCharacterProfession.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_NewCharacterProfession.ForeColor = System.Drawing.Color.White;
            this.lbl_NewCharacterProfession.Location = new System.Drawing.Point(13, 78);
            this.lbl_NewCharacterProfession.Name = "lbl_NewCharacterProfession";
            this.lbl_NewCharacterProfession.Size = new System.Drawing.Size(89, 20);
            this.lbl_NewCharacterProfession.TabIndex = 23;
            this.lbl_NewCharacterProfession.Text = "Profession";
            // 
            // lbl_NewCharacterName
            // 
            this.lbl_NewCharacterName.AutoSize = true;
            this.lbl_NewCharacterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lbl_NewCharacterName.Location = new System.Drawing.Point(13, 22);
            this.lbl_NewCharacterName.Name = "lbl_NewCharacterName";
            this.lbl_NewCharacterName.Size = new System.Drawing.Size(137, 20);
            this.lbl_NewCharacterName.TabIndex = 23;
            this.lbl_NewCharacterName.Text = "Character Name:";
            // 
            // listbox_ProfessionList
            // 
            this.listbox_ProfessionList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.listbox_ProfessionList.FormattingEnabled = true;
            this.listbox_ProfessionList.ItemHeight = 20;
            this.listbox_ProfessionList.Items.AddRange(new object[] {
            "Warrior",
            "Mage",
            "Spiritualist"});
            this.listbox_ProfessionList.Location = new System.Drawing.Point(17, 100);
            this.listbox_ProfessionList.Name = "listbox_ProfessionList";
            this.listbox_ProfessionList.Size = new System.Drawing.Size(248, 64);
            this.listbox_ProfessionList.TabIndex = 24;
            // 
            // txtbox_NewCharacterName
            // 
            this.txtbox_NewCharacterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtbox_NewCharacterName.Location = new System.Drawing.Point(17, 45);
            this.txtbox_NewCharacterName.Name = "txtbox_NewCharacterName";
            this.txtbox_NewCharacterName.Size = new System.Drawing.Size(248, 26);
            this.txtbox_NewCharacterName.TabIndex = 23;
            // 
            // btn_CreateNewChar
            // 
            this.btn_CreateNewChar.ForeColor = System.Drawing.Color.Black;
            this.btn_CreateNewChar.Location = new System.Drawing.Point(17, 240);
            this.btn_CreateNewChar.Name = "btn_CreateNewChar";
            this.btn_CreateNewChar.Size = new System.Drawing.Size(248, 35);
            this.btn_CreateNewChar.TabIndex = 22;
            this.btn_CreateNewChar.Text = "Create New Character";
            this.btn_CreateNewChar.UseVisualStyleBackColor = true;
            this.btn_CreateNewChar.Click += new System.EventHandler(this.btn_CreateNewChar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtbox_NameToLoad);
            this.groupBox1.Controls.Add(this.btn_CreateNewChar);
            this.groupBox1.Controls.Add(this.btn_LoadCharacter);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(284, 292);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Log In";
            // 
            // grpbox_Monster
            // 
            this.grpbox_Monster.Controls.Add(this.txtbox_MonsterNameInput);
            this.grpbox_Monster.Controls.Add(this.btn_LoadNewMonster);
            this.grpbox_Monster.Controls.Add(this.lbl_MonsterHealth);
            this.grpbox_Monster.Controls.Add(this.lbl_MonsterLevel);
            this.grpbox_Monster.Controls.Add(this.lbl_MonsterName);
            this.grpbox_Monster.Location = new System.Drawing.Point(568, 13);
            this.grpbox_Monster.Name = "grpbox_Monster";
            this.grpbox_Monster.Size = new System.Drawing.Size(442, 597);
            this.grpbox_Monster.TabIndex = 26;
            this.grpbox_Monster.TabStop = false;
            this.grpbox_Monster.Text = "Monster";
            // 
            // lbl_MonsterName
            // 
            this.lbl_MonsterName.AutoSize = true;
            this.lbl_MonsterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MonsterName.ForeColor = System.Drawing.Color.White;
            this.lbl_MonsterName.Location = new System.Drawing.Point(7, 20);
            this.lbl_MonsterName.Name = "lbl_MonsterName";
            this.lbl_MonsterName.Size = new System.Drawing.Size(105, 20);
            this.lbl_MonsterName.TabIndex = 0;
            this.lbl_MonsterName.Text = "Monter Name";
            // 
            // lbl_MonsterLevel
            // 
            this.lbl_MonsterLevel.AutoSize = true;
            this.lbl_MonsterLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MonsterLevel.ForeColor = System.Drawing.Color.Transparent;
            this.lbl_MonsterLevel.Location = new System.Drawing.Point(7, 46);
            this.lbl_MonsterLevel.Name = "lbl_MonsterLevel";
            this.lbl_MonsterLevel.Size = new System.Drawing.Size(108, 20);
            this.lbl_MonsterLevel.TabIndex = 1;
            this.lbl_MonsterLevel.Text = "Monster Level";
            // 
            // lbl_MonsterHealth
            // 
            this.lbl_MonsterHealth.AutoSize = true;
            this.lbl_MonsterHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MonsterHealth.ForeColor = System.Drawing.Color.White;
            this.lbl_MonsterHealth.Location = new System.Drawing.Point(7, 72);
            this.lbl_MonsterHealth.Name = "lbl_MonsterHealth";
            this.lbl_MonsterHealth.Size = new System.Drawing.Size(118, 20);
            this.lbl_MonsterHealth.TabIndex = 2;
            this.lbl_MonsterHealth.Text = "Monster Health";
            // 
            // btn_LoadNewMonster
            // 
            this.btn_LoadNewMonster.Location = new System.Drawing.Point(12, 213);
            this.btn_LoadNewMonster.Name = "btn_LoadNewMonster";
            this.btn_LoadNewMonster.Size = new System.Drawing.Size(205, 43);
            this.btn_LoadNewMonster.TabIndex = 3;
            this.btn_LoadNewMonster.Text = "Load New Monster";
            this.btn_LoadNewMonster.UseVisualStyleBackColor = true;
            this.btn_LoadNewMonster.Click += new System.EventHandler(this.btn_LoadNewMonster_Click);
            // 
            // txtbox_MonsterNameInput
            // 
            this.txtbox_MonsterNameInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_MonsterNameInput.Location = new System.Drawing.Point(12, 181);
            this.txtbox_MonsterNameInput.Name = "txtbox_MonsterNameInput";
            this.txtbox_MonsterNameInput.Size = new System.Drawing.Size(204, 26);
            this.txtbox_MonsterNameInput.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1037, 622);
            this.Controls.Add(this.grpbox_Monster);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_SaveChar);
            this.Controls.Add(this.btn_deleteChar);
            this.Controls.Add(this.grpbox_NewCharacter);
            this.Controls.Add(this.btn_Player1_Attack);
            this.Controls.Add(this.btn_UseManaPotion);
            this.Controls.Add(this.btn_UseHealthPotion);
            this.Controls.Add(this.btn_UseMagic);
            this.Controls.Add(this.btn_TakeDamage);
            this.Controls.Add(this.lbl_Player1_MagicDef);
            this.Controls.Add(this.lbl_Player1_MagicDamage);
            this.Controls.Add(this.lbl_Player1_PhysDef);
            this.Controls.Add(this.lbl_Player1_physdam);
            this.Controls.Add(this.lbl_Player1_Level);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_Player1_Mana);
            this.Controls.Add(this.lbl_Player1_Health);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Player1_Name);
            this.Name = "Form1";
            this.Text = "RPG System";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpbox_NewCharacter.ResumeLayout(false);
            this.grpbox_NewCharacter.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpbox_Monster.ResumeLayout(false);
            this.grpbox_Monster.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Player1_Name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Player1_Health;
        private System.Windows.Forms.Label lbl_Player1_Mana;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_Player1_Level;
        private System.Windows.Forms.Label lbl_Player1_physdam;
        private System.Windows.Forms.Label lbl_Player1_PhysDef;
        private System.Windows.Forms.Label lbl_Player1_MagicDamage;
        private System.Windows.Forms.Label lbl_Player1_MagicDef;
        private System.Windows.Forms.Button btn_LoadCharacter;
        private System.Windows.Forms.Button btn_TakeDamage;
        private System.Windows.Forms.Button btn_UseMagic;
        private System.Windows.Forms.Button btn_UseHealthPotion;
        private System.Windows.Forms.Button btn_UseManaPotion;
        private System.Windows.Forms.Timer tickTimer;
        private System.Windows.Forms.Button btn_Player1_Attack;
        private System.Windows.Forms.TextBox txtbox_NameToLoad;
        private System.Windows.Forms.Button btn_deleteChar;
        private System.Windows.Forms.Button btn_SaveChar;
        private System.Windows.Forms.GroupBox grpbox_NewCharacter;
        private System.Windows.Forms.Label lbl_NewCharacterProfession;
        private System.Windows.Forms.Label lbl_NewCharacterName;
        private System.Windows.Forms.ListBox listbox_ProfessionList;
        private System.Windows.Forms.TextBox txtbox_NewCharacterName;
        private System.Windows.Forms.Button btn_CreateNewChar;
        private System.Windows.Forms.Button btn_SubmitNewCharacter;
        private System.Windows.Forms.Button btn_CancelNewCharacter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox grpbox_Monster;
        private System.Windows.Forms.Label lbl_MonsterHealth;
        private System.Windows.Forms.Label lbl_MonsterLevel;
        private System.Windows.Forms.Label lbl_MonsterName;
        private System.Windows.Forms.Button btn_LoadNewMonster;
        private System.Windows.Forms.TextBox txtbox_MonsterNameInput;
    }
}

