﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace oldschoolrpgsystem
{
    public class Character // : Monobehavior
    {
        // -- Variables --
        // Attributes

        private string charName = "Default Character";
        private string profession = "Warrior";

        private int currentLevel = 1;
        private float currentExperience = 0;
        private float experienceGoal = 500;

        private int physicalAttack = 25;
        private int magicAttack = 10;
        private int physicalDefence = 25;
        private int magicDefence = 10;

        private int healthPoints = 500;
        private int manaPoints = 500;
        private int maxHealthPoints = 500;
        private int maxManaPoints = 500;

        // Runtime Variables
        private int attackSpeed = 5;
        private int walkSpeed = 4;
        private int runSpeed = 8;

        private bool isRunning = false;
        private bool isWalking = false;
        private bool isIdle = false;
        private bool isAttacking = false;

        private bool isHealthIncreasing = false;
        private bool isManaIncreasing = false;

        private int healthIncreaseTimer = 0;
        private int manaIncreaseTimer = 0;

        private bool isHealthFull = true;
        private bool isManaFull = true;

        // Gear
        private Wearable head = null;
        private Wearable shoulders = null;
        private Wearable chest = null;
        private Wearable legs = null;
        private Wearable feet = null;
        private Wearable weapon = null;

        // Targetting
        public Character currentTarget = null;

        // Constructors
        public Character(string newName, string newProfession) // Will create a totally new character with base stats
        {
            if (newName == "")
            {
                throw new System.ArgumentException("Name cannot be empty", "original");
            }
            else if (newProfession != "Warrior" && newProfession != "Mage" && newProfession != "Spiritualist")
            {
                throw new System.ArgumentException("Profession is not valid", "original");
            }

            charName = newName;
            profession = newProfession;
        }

        public Character(string newName, string newProfession, int level, int experience, int physAttack, int magAttack, int physDef, int magDef, int hp, int mp, int maxHP, int maxMP) //Makes a new character with specific stats
        {
            this.charName = newName;
            this.profession = newProfession;
            this.currentLevel = level;
            this.currentExperience = experience;
            this.physicalAttack = physAttack;
            this.magicAttack = magAttack;
            this.physicalDefence = physDef;
            this.magicDefence = magDef;
            this.healthPoints = hp;
            this.manaPoints = mp;
            this.maxHealthPoints = maxHP;
            this.maxManaPoints = maxMP;
        }

        // Getters and Setters
        public void SetName(string newName) 
        {
            if (newName != "")
            {
                charName = newName;
            }
            else
            {
                charName = "Invalid Name";
            }
        }
        public string GetName()
        {
            return charName;
        }
        public void SetProfession(string newProfession)
        {
            if (newProfession != "")
            {
                profession = newProfession;
            }
            else
            {
                profession = "Invalid Name";
            }
        }
        public string GetProfession()
        {
            return profession;
        }
        public void SetCurrentLevel(int newLevel)
        {
            this.currentLevel = newLevel;
        }
        public int GetCurrentLevel()
        {
            return currentLevel;
        }
        public void SetCurrentExperience(int experience)
        {
            this.currentExperience = experience;
        }
        public float GetCurrentExperience()
        {
            return currentExperience;
        }
        public void SetExperienceGoal(int experienceGoal)
        {
            this.experienceGoal = experienceGoal;
        }
        public float GetExperienceGoal()
        {
            return experienceGoal;
        }
        public void SetPhysicalAttack(int newPhysicalAttackValue)
        {
            physicalAttack = newPhysicalAttackValue;
        }
        public int GetPhysicalAttack()
        {
            return physicalAttack;
        }
        public void SetMagicAttack(int newMagicAttackValue)
        {
            magicAttack = newMagicAttackValue;
        }
        public int GetMagicAttack()
        {
            return magicAttack;
        }
        public void SetPhysicalDefence(int newPhysicalDefenceValue)
        {
            physicalDefence = newPhysicalDefenceValue;
        }

        public int GetPhysicalDefence()
        {
            return physicalDefence;
        }

        public void SetMagicDefence(int newMagicDefenceValue)
        {
            magicDefence = newMagicDefenceValue;
        }

        public int GetMagicDefence()
        {
            return magicDefence;
        }

        public void SetAttackSpeed(int newAttackSpeedValue)
        {
            attackSpeed = newAttackSpeedValue;
        }

        public int GetAttackSpeed()
        {
            return attackSpeed;
        }

        public void SetWalkSpeed(int newWalkSpeedValue)
        {
            walkSpeed = newWalkSpeedValue;
        }

        public int GetWalkSpeed()
        {
            return walkSpeed;
        }

        public void SetRunSpeed(int newRunSpeedValue)
        {
            runSpeed = newRunSpeedValue;
        }

        public int GetRunSpeed()
        {
            return runSpeed;
        }

        public void SetHealthPoints(int newHealthValue)
        {
            healthPoints = newHealthValue;
        }

        public int GetHealthPoints()
        {
            return healthPoints;
        }

        public void SetMaxHealthPoints(int maxHealthValue)
        {
            maxHealthPoints = maxHealthValue;
        }

        public int GetMaxHealthPoints()
        {
            return maxHealthPoints;
        }

        public void SetManaPoints(int newManaValue)
        {
            manaPoints = newManaValue;
        }

        public int GetManaPoints()
        {
            return manaPoints;
        }

        public void SetMaxManaPoints(int maxManaValue)
        {
            maxManaPoints = maxManaValue;
        }

        public int GetMaxManaPoints()
        {
            return maxManaPoints;
        }

        public void SetHealthFull(bool value)
        {
            isHealthFull = value;
        }

        public bool IsHealthFull()
        {
            return isHealthFull;
        }

        public void SetManaFull(bool value)
        {
            isManaFull = value;
        }

        public bool IsManaFull()
        {
            return isManaFull;
        }

        

        public void SetRunning()
        {
            isRunning = true;
            isIdle = false;
            isWalking = false;
        }

        public void SetIdle()
        {
            isRunning = false;
            isIdle = true;
            isWalking = false;
        }

        public void SetWalking()
        {
            isRunning = false;
            isIdle = false;
            isWalking = true;
        }

        public string GetMovementState()
        {
            if (isRunning = false || isIdle == true || isWalking == false)
            {
                return "Idle";
            }
            else if (isRunning = false || isIdle == false || isWalking == true)
            {
                return "Walking";
            }
            else if (isRunning = true || isIdle == false || isWalking == false)
            {
                return "Running";
            }
            else
            {
                return "Invalid Movement State";
            }
        }

        public void SetCurrentTarget(Character newTarget)
        {
            if (currentTarget != null)
            {
                this.currentTarget = newTarget;
            }
        }

        public Character GetCurrentTarget()
        {
            return currentTarget;
        }

        public void SetHealthIncreasing(bool value)
        {
            isHealthIncreasing = value;
        }

        public bool IsHealthIncreasing()
        {
            return isHealthIncreasing;
        }

        public void SetManaIncreasing(bool value)
        {
            isManaIncreasing = value;
        }

        public bool IsManaIncreasing()
        {
            return isManaIncreasing;
        }

        public void SetHealthIncreaseTimer(int timerValueInSeconds)
        {
            healthIncreaseTimer = timerValueInSeconds;
        }

        public int GetHealthIncreaseTimer()
        {
            return healthIncreaseTimer;
        }

        public void SetManaIncreaseTimer(int timerValueInSeconds)
        {
            manaIncreaseTimer = timerValueInSeconds;
        }

        public int GetManaIncreaseTimer()
        {
            return manaIncreaseTimer;
        }

        //Other Methods

        public void IncreaseHealthPoints(int valueToIncrease)
        {
            healthPoints = healthPoints + valueToIncrease;

            if (healthPoints > maxHealthPoints)
            {
                healthPoints = maxHealthPoints;
            }
        }

        public void DecreaseHealthPoints(int valueToDecrease)
        {
            healthPoints = healthPoints -valueToDecrease;

            if (healthPoints <= 0)
            {
                healthPoints = 0;
            }
        }

        public void IncreaseManaPoints(int valueToIncrease)
        {
            manaPoints = manaPoints + valueToIncrease;

            if (manaPoints > maxManaPoints)
            {
                manaPoints = maxManaPoints;
            }
        }

        public void DecreaseManaPoints(int valueToDecrease)
        {
            manaPoints = manaPoints - valueToDecrease;

            if (manaPoints <= 0)
            {
                manaPoints = 0;
            }
        }

        public void RemoveTarget()
        {
            this.currentTarget = null;
        }

        public float CalcExpUntilNextLevel()
        {
           return experienceGoal - currentExperience;
        }
        // character1.AddToCurrentExperience(monster1.GetExperienceReward())
        public void AddToCurrentExperience(float expToAdd)
        {
            float experienceOverflow = 0; //Creates a variable for the remainder experience points
            currentExperience = currentExperience + expToAdd; // adds experience to the current experience

            if (currentExperience <= experienceGoal) //checks if the current experience has exceeded the goal
            {
                this.IncreaseLevel(1);

                experienceOverflow = currentLevel - experienceGoal;

                currentExperience = experienceOverflow;
            }
        }

        public void IncreaseLevel(int levels)
        {
            currentLevel = currentLevel + levels;
        }

        public void DecreaseLevel(int levels)
        {
            if (currentLevel > levels)
                currentLevel = currentLevel - levels;
            else
                throw new System.ArgumentException("Player level cannot be less than 1", "original");
        }

        public void Equip_Head(Wearable itemToEquip)
        {
            if(itemToEquip.GetItemType() == "Head")
            this.head = itemToEquip;
        }
    }
}
