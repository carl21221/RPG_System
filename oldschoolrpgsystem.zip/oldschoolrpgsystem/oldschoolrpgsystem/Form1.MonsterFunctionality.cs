﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace oldschoolrpgsystem
{
    public partial class Form1
    {
        public string[] GetMonsterStatsAsStringArray(string monsterName)
        {
            string[] arrayToReturn = { "0", "0", "0", "0", "0", "0", "0", "0", "0", "0" };
            string fileDirectory = @"D:\Visual Studio Projects\Old School RPG System\oldschoolrpgsystem\oldschoolrpgsystem\data\monsters.txt";
            string currentLine = "";
            bool monsterFound = false;

            // string monsterName, int level, int physAttack, int magAttack, int physDef, int magDef, int health, float experienceReward, int walkSpeed, int attackSpeed
            using (StreamReader reader = new StreamReader(fileDirectory)) //use stream reader to find the monster in the file and save the full line
            {
                do
                {
                    currentLine = reader.ReadLine();
                    if (currentLine.StartsWith(monsterName))
                    {
                        monsterFound = true;
                        break;
                    }
                } while (!reader.EndOfStream);
            }
            
            if (monsterFound)
            {
                arrayToReturn = currentLine.Split(',');
            }

            return arrayToReturn;
        }
    }
}